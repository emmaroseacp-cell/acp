# ACP Media Downloader Pro — Windows Desktop Software

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com)
[![Platform](https://img.shields.io/badge/platform-Windows%2010%20%7C%2011-cyan.svg)](https://microsoft.com/windows)
[![License](https://img.shields.io/badge/license-Proprietary%20ACP-darkblue.svg)](https://acpsoftware.com)

**ACP Media Downloader Pro** is a high-performance Windows desktop application engineered under the **ACP** software brand. It provides universal URL-based media extraction, stream inspection, batch downloading, and queue management for publicly accessible media and websites that permit downloading.

---

## Brand Identity & Aesthetic
- **Official Name**: ACP Media Downloader Pro
- **Brand Abbreviation**: ACP
- **Theme**: Deep navy (`#030712`), obsidian black (`#040814`), electric blue (`#00E5FF`), sky blue (`#0284c7`), silver, and crisp white.
- **Application Monogram**: Custom geometric metallic ACP insignia.

---

## Key Modules & Functional Pages

1. **Home Dashboard**
   - KPI telemetry (live throughput, active streams, completed downloads, total transferred volume).
   - Universal fast URL grabber.
   - 1-click test verification samples (NASA HD MP4, Wikimedia high-res Earth photo, standard SVG, acoustic audio sample).
   - Live stream monitoring with progress bars, speeds, and ETA.

2. **Universal Downloader**
   - Deep inspection of arbitrary public URLs.
   - Extracts HTML5 video streams, high-res images, audio tags, OpenGraph/Twitter social media assets, and direct download links.
   - Filter tabs: All, Videos, Images, Audio, Documents.
   - Multi-select with individual downloading or instant ZIP bundling.

3. **Image Downloader**
   - Dedicated high-fidelity photo capture (JPG, PNG, WebP, GIF, SVG).
   - In-app image preview modal before saving.
   - Preserves original resolutions and avoids accidental overwriting.
   - Batch ZIP exporter.

4. **Video Downloader**
   - Direct video stream detection (MP4, WebM, etc.).
   - Resolution identification (1080p, 720p, 480p, 360p).
   - Built-in HTML5 in-app video player preview.
   - Transparent compliance notices explaining DRM and paywall protections.

5. **Batch Downloader**
   - Multi-URL paste area with line-by-line parsing.
   - Automated media type categorization.
   - Select All / custom selection controls.
   - Concurrency throttling to respect remote host capacity.

6. **Download Manager**
   - Real-time download progress (downloaded bytes, total bytes, percent).
   - Actual transfer speeds (KB/s and MB/s) sampled every 300ms.
   - Estimated Time of Arrival (ETA) calculation.
   - True Pause & Resume using HTTP Range headers (`bytes=...-`).
   - Cancel and Retry with memory cleanup.
   - Save to disk and clear finished tasks.

7. **Download History**
   - Searchable log of past operations.
   - Persistent synchronization with SQLite / browser IndexedDB cache.
   - Export history to CSV or JSON formats.
   - Re-download and single item deletion.

8. **Settings**
   - Configurable Windows target directory (`C:\Users\...\Downloads\ACP Media`).
   - Max concurrent download slider (1 to 5 concurrent streams).
   - User-Agent profile selector (Windows Chrome, Edge, Firefox, Native ACP).
   - Windows desktop alert notifications toggle.
   - SQLite cache inspection.

9. **About ACP Media Downloader Pro**
   - Full software specifications and Windows 10/11 compatibility matrix.
   - SSRF and path traversal perimeter defense documentation.
   - **Downloadable Windows setup package** (`ACP_Media_Downloader_Pro_Setup.bat` / `.exe`).
   - Copyable NSIS Modern UI installer script (`installer.nsi`).

---

## Security & Ethical Safeguards

- **SSRF Protection**: Prohibits requests to localhost, loopback (`127.0.0.1`, `::1`), link-local (`169.254.x.x`), and private enterprise subnets (`10.x.x.x`, `192.168.x.x`, `172.16-31.x.x`).
- **Path Traversal Guard**: Sanitizes filenames and validates that target save paths remain strictly within the user-specified directory.
- **DRM & Access Control Compliance**: Does not bypass Widevine/PlayReady DRM, encrypted streams, paywalls, or private authentication barriers.
- **Zero Credential Interception**: Never prompts for or captures private third-party credentials.

---

## Building the Windows `.exe` Installer

### Prerequisites
- Node.js (v18.x or v20.x+)
- Windows 10 or Windows 11 64-bit

### Steps to Build

```bash
# 1. Install dependencies
npm install

# 2. Build frontend and backend bundles
npm run build

# 3. Generate the Windows NSIS Installer (.exe)
npx electron-builder --win nsis
```

The compiled installer will be located at:
`release/ACP Media Downloader Pro Setup 1.0.0.exe`
