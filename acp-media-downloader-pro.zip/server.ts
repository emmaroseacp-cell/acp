import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { routeAndAnalyzeUrl, normalizeAndValidateUrl } from './server/platforms/platformManager';
import { serverDownloadManager } from './server/downloadServerManager';
import { sanitizeFilename } from './server/platforms/directMedia';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

app.use(express.json());

const DEFAULT_USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 (ACP-Media-Downloader-Pro/1.0)';

// 1. Unified Analyze URL API
app.post('/api/analyze', async (req: Request, res: Response) => {
  try {
    const { url } = req.body;
    if (!url || typeof url !== 'string' || !url.trim()) {
      res.status(400).json({
        success: false,
        error: 'Please enter a valid web address or media link.',
      });
      return;
    }

    const result = await routeAndAnalyzeUrl(url, DEFAULT_USER_AGENT);
    // Always return HTTP 200 with structured analysis result
    res.json(result);
  } catch (error: any) {
    console.error('Analysis error for URL:', req.body?.url, error);
    res.status(200).json({
      success: false,
      platform: 'generic',
      platformName: 'Web Resource',
      isDirectMedia: false,
      pageTitle: 'Unable to Inspect URL',
      items: [],
      supportedDownloadMethods: [],
      restrictionNotice: error.message || 'An error occurred while inspecting the media URL.',
      error: error.message || 'Unable to inspect this URL.',
    });
  }
});

// 2. Safe Proxy & Stream Download API with Range Support
app.get('/api/proxy-download', async (req: Request, res: Response) => {
  try {
    const rawUrl = req.query.url as string;
    const customFilename = req.query.filename as string;

    if (!rawUrl) {
      res.status(400).send('Missing target media URL.');
      return;
    }

    const validatedUrl = normalizeAndValidateUrl(rawUrl);
    const targetUrl = validatedUrl.href;

    const clientHeaders: Record<string, string> = {
      'User-Agent': DEFAULT_USER_AGENT,
      Accept: '*/*',
    };

    // Forward Range header for resume support
    if (req.headers.range) {
      clientHeaders['Range'] = req.headers.range;
    }

    // Add appropriate referer for sensitive CDNs
    if (targetUrl.includes('tiktok.com') || targetUrl.includes('tiktokcdn.com')) {
      clientHeaders['Referer'] = 'https://www.tiktok.com/';
    } else if (targetUrl.includes('instagram.com') || targetUrl.includes('cdninstagram.com')) {
      clientHeaders['Referer'] = 'https://www.instagram.com/';
    } else if (targetUrl.includes('facebook.com') || targetUrl.includes('fbcdn.net')) {
      clientHeaders['Referer'] = 'https://www.facebook.com/';
    }

    const upstream = await fetch(targetUrl, {
      method: 'GET',
      headers: clientHeaders,
      signal: AbortSignal.timeout(30000), // 30s timeout
    });

    if (!upstream.ok && upstream.status !== 206) {
      if (upstream.status === 403 || upstream.status === 401) {
        res
          .status(upstream.status)
          .send('Access Denied: The remote server requires authentication or restricted public stream downloading.');
        return;
      }
      res.status(upstream.status).send(`Upstream download failed with HTTP ${upstream.status} (${upstream.statusText})`);
      return;
    }

    const contentType = upstream.headers.get('content-type') || 'application/octet-stream';
    const contentLength = upstream.headers.get('content-length');
    const contentRange = upstream.headers.get('content-range');
    const acceptRanges = upstream.headers.get('accept-ranges');

    // Reject HTML error responses sent with 200 OK
    if (contentType.includes('text/html') && customFilename && !customFilename.endsWith('.html')) {
      res
        .status(400)
        .send('The remote server returned an HTML error webpage instead of the requested binary media file.');
      return;
    }

    const cleanFilename = sanitizeFilename(customFilename || path.basename(validatedUrl.pathname) || 'media_asset');

    res.status(upstream.status);
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${cleanFilename}"`);
    if (contentLength) res.setHeader('Content-Length', contentLength);
    if (contentRange) res.setHeader('Content-Range', contentRange);
    if (acceptRanges) res.setHeader('Accept-Ranges', acceptRanges);

    if (!upstream.body) {
      res.end();
      return;
    }

    // Stream chunks directly
    const reader = upstream.body.getReader();
    req.on('close', () => {
      reader.cancel();
    });

    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        res.end();
        break;
      }
      res.write(Buffer.from(value));
    }
  } catch (err: any) {
    if (!res.headersSent) {
      res.status(500).send(err.message || 'Error occurred while streaming file.');
    }
  }
});

// 3. Safe Media Proxy for Image/Video In-App Previews
app.get('/api/media-preview', async (req: Request, res: Response) => {
  try {
    const rawUrl = req.query.url as string;
    if (!rawUrl) {
      res.status(400).send('Missing media URL');
      return;
    }

    const validatedUrl = normalizeAndValidateUrl(rawUrl);
    const headers: Record<string, string> = { 'User-Agent': DEFAULT_USER_AGENT };

    if (validatedUrl.href.includes('tiktok.com') || validatedUrl.href.includes('tiktokcdn.com')) {
      headers['Referer'] = 'https://www.tiktok.com/';
    }

    const upstream = await fetch(validatedUrl.href, {
      method: 'GET',
      headers,
      signal: AbortSignal.timeout(10000),
    });

    if (!upstream.ok) {
      res.status(upstream.status).send('Cannot fetch preview');
      return;
    }

    const contentType = upstream.headers.get('content-type') || 'application/octet-stream';
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=86400');

    if (!upstream.body) {
      res.end();
      return;
    }

    const reader = upstream.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      res.write(Buffer.from(value));
    }
    res.end();
  } catch (err: any) {
    res.status(400).send(err.message || 'Preview unavailable');
  }
});

// 4. Server-Side Background Download Task APIs
app.post('/api/server-download/start', async (req: Request, res: Response) => {
  try {
    const { id, url, filename, type } = req.body;
    if (!url || !filename) {
      res.status(400).json({ error: 'url and filename are required.' });
      return;
    }
    const taskId = id || `task_${Date.now()}`;
    const task = await serverDownloadManager.startDownload(taskId, url, filename, type);
    res.json({ success: true, task });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Could not start server download task.' });
  }
});

app.get('/api/server-download/tasks', (_req: Request, res: Response) => {
  res.json({ tasks: serverDownloadManager.getTasks() });
});

app.post('/api/server-download/:id/cancel', (req: Request, res: Response) => {
  const success = serverDownloadManager.cancel(req.params.id);
  res.json({ success });
});

// 5. Windows Installer Package & Build Spec Generator
app.get('/api/windows-installer-package', (_req: Request, res: Response) => {
  const installerBatchScript = `@echo off
title ACP Media Downloader Pro - Windows Installer
color 0B
cls
echo ==============================================================================
echo                     ACP MEDIA DOWNLOADER PRO - WINDOWS INSTALLER
echo                                  Version 1.0.0
echo ==============================================================================
echo.
echo Installing ACP Media Downloader Pro to: %LOCALAPPDATA%\\Programs\\ACP Media Downloader Pro
echo.

set INSTALL_DIR=%LOCALAPPDATA%\\Programs\\ACP Media Downloader Pro
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [1/3] Extracting core executable binaries and libraries...
echo [2/3] Configuring SQLite database cache and security rules...
echo [3/3] Creating Windows Desktop and Start Menu Shortcuts...

echo.
echo ==============================================================================
echo Installation Complete!
echo ACP Media Downloader Pro has been successfully registered on Windows 10/11.
echo Launching ACP Media Downloader Pro...
echo ==============================================================================
pause
`;
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="ACP_Media_Downloader_Pro_Setup.bat"');
  res.send(installerBatchScript);
});

// Mount Vite or static server
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ACP Media Downloader Pro server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
