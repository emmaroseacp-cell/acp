import { URL } from 'url';
import path from 'path';
import net from 'net';

export class SecurityGuard {
  private static PRIVATE_IP_RANGES = [
    /^127\./,
    /^10\./,
    /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
    /^192\.168\./,
    /^169\.254\./,
    /^0\.0\.0\.0/,
    /^::1$/,
    /^fc00:/i,
    /^fe80:/i,
  ];

  public static sanitizeFilename(input: string, fallback = 'download'): string {
    if (!input) return fallback;
    const basename = path.basename(input).split('?')[0].split('#')[0];
    const cleaned = basename.replace(/[^a-zA-Z0-9._-]/g, '_');
    return cleaned.length > 0 ? cleaned : fallback;
  }

  public static resolveSafeLocalPath(baseDir: string, userFilename: string): string {
    const cleanFilename = this.sanitizeFilename(userFilename);
    const resolvedPath = path.resolve(baseDir, cleanFilename);

    // Guard against path traversal out of base directory
    if (!resolvedPath.startsWith(path.resolve(baseDir))) {
      throw new Error('Access denied: Path traversal detected.');
    }
    return resolvedPath;
  }

  public static validateUrl(inputUrl: string): URL {
    let parsed: URL;
    try {
      parsed = new URL(inputUrl.trim());
    } catch {
      throw new Error('Invalid URL format supplied. Please enter a valid HTTP/HTTPS address.');
    }

    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      throw new Error(`Forbidden protocol: ${parsed.protocol}. Only HTTP and HTTPS are permitted.`);
    }

    const hostname = parsed.hostname.toLowerCase();
    if (hostname === 'localhost' || hostname.endsWith('.localhost')) {
      throw new Error('Security Restriction (SSRF): Access to localhost is restricted.');
    }

    if (net.isIP(hostname)) {
      for (const pattern of this.PRIVATE_IP_RANGES) {
        if (pattern.test(hostname)) {
          throw new Error('Security Restriction (SSRF): Access to private networks is forbidden.');
        }
      }
    }

    return parsed;
  }
}
