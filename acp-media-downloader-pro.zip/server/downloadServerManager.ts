import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { normalizeAndValidateUrl } from './platforms/platformManager';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface ServerDownloadTask {
  id: string;
  url: string;
  filename: string;
  type: string;
  totalBytes: number;
  downloadedBytes: number;
  progress: number;
  speed: number;
  eta: number;
  status: 'queued' | 'downloading' | 'paused' | 'completed' | 'failed' | 'cancelled';
  filePath: string;
  error?: string;
  startedAt: number;
  completedAt?: number;
}

export class ServerDownloadManager {
  private tasks: Map<string, ServerDownloadTask> = new Map();
  private abortControllers: Map<string, AbortController> = new Map();
  private downloadDir: string;

  constructor() {
    this.downloadDir = path.resolve(__dirname, '..', 'downloads');
    if (!fs.existsSync(this.downloadDir)) {
      try {
        fs.mkdirSync(this.downloadDir, { recursive: true });
      } catch {
        // fallback to /tmp if needed
      }
    }
  }

  public getTasks(): ServerDownloadTask[] {
    return Array.from(this.tasks.values());
  }

  public getTask(id: string): ServerDownloadTask | undefined {
    return this.tasks.get(id);
  }

  public cancel(id: string): boolean {
    const controller = this.abortControllers.get(id);
    if (controller) {
      controller.abort();
    }
    const task = this.tasks.get(id);
    if (task) {
      task.status = 'cancelled';
      task.speed = 0;
      task.eta = 0;
      return true;
    }
    return false;
  }

  public async startDownload(
    id: string,
    rawUrl: string,
    filename: string,
    type = 'document'
  ): Promise<ServerDownloadTask> {
    const validatedUrl = normalizeAndValidateUrl(rawUrl);
    const safeFilename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
    const targetFilePath = path.join(this.downloadDir, safeFilename);

    const task: ServerDownloadTask = {
      id,
      url: validatedUrl.href,
      filename: safeFilename,
      type,
      totalBytes: 0,
      downloadedBytes: 0,
      progress: 0,
      speed: 0,
      eta: 0,
      status: 'downloading',
      filePath: targetFilePath,
      startedAt: Date.now(),
    };

    this.tasks.set(id, task);

    const controller = new AbortController();
    this.abortControllers.set(id, controller);

    // Run download in background
    this.executeStream(task, controller).catch((err) => {
      task.status = 'failed';
      task.error = err.message || 'Stream download error';
      task.speed = 0;
      task.eta = 0;
    });

    return task;
  }

  private async executeStream(task: ServerDownloadTask, controller: AbortController) {
    let retries = 0;
    const maxRetries = 2;

    while (retries <= maxRetries) {
      try {
        const headers: Record<string, string> = {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
          Accept: '*/*',
        };

        const res = await fetch(task.url, {
          method: 'GET',
          headers,
          signal: controller.signal,
        });

        if (!res.ok) {
          throw new Error(`Upstream host returned HTTP ${res.status}: ${res.statusText}`);
        }

        const contentType = res.headers.get('content-type') || '';
        if (contentType.includes('text/html') && !task.filename.endsWith('.html')) {
          throw new Error('Host returned an HTML webpage instead of the requested binary media file.');
        }

        const lenHeader = res.headers.get('content-length');
        if (lenHeader) {
          task.totalBytes = parseInt(lenHeader, 10);
        }

        const fileStream = fs.createWriteStream(task.filePath);
        if (!res.body) {
          throw new Error('No readable data stream received from host.');
        }

        const reader = res.body.getReader();
        let lastTick = performance.now();
        let bytesSinceTick = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          fileStream.write(Buffer.from(value));
          task.downloadedBytes += value.length;
          bytesSinceTick += value.length;

          const now = performance.now();
          if (now - lastTick >= 400) {
            const timeDiffSec = (now - lastTick) / 1000;
            task.speed = Math.round(bytesSinceTick / timeDiffSec);
            lastTick = now;
            bytesSinceTick = 0;

            if (task.totalBytes > 0) {
              task.progress = Math.min(100, Math.round((task.downloadedBytes / task.totalBytes) * 100));
              const rem = task.totalBytes - task.downloadedBytes;
              task.eta = task.speed > 0 ? Math.round(rem / task.speed) : 0;
            }
          }
        }

        fileStream.end();

        // Verify file on disk
        if (fs.existsSync(task.filePath)) {
          const stats = fs.statSync(task.filePath);
          if (stats.size === 0) {
            throw new Error('Downloaded file is 0 bytes. Transfer was truncated or rejected.');
          }
          task.downloadedBytes = stats.size;
          task.totalBytes = stats.size;
          task.progress = 100;
        }

        task.status = 'completed';
        task.speed = 0;
        task.eta = 0;
        task.completedAt = Date.now();
        return;
      } catch (err: any) {
        if (controller.signal.aborted) {
          task.status = 'cancelled';
          return;
        }

        retries++;
        if (retries > maxRetries) {
          task.status = 'failed';
          task.error = err.message || 'Download connection aborted.';
          task.speed = 0;
          task.eta = 0;
          throw err;
        }
        // Small delay before retry
        await new Promise((r) => setTimeout(r, 1000));
      }
    }
  }
}

export const serverDownloadManager = new ServerDownloadManager();
