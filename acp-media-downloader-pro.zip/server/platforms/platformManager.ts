import net from 'net';
import { PlatformAnalysisResult } from './types';
import { isYouTubeUrl, handleYouTube } from './youtube';
import { isTikTokUrl, handleTikTok } from './tiktok';
import { isInstagramUrl, handleInstagram } from './instagram';
import { isFacebookUrl, handleFacebook } from './facebook';
import { handleDirectOrGeneric } from './directMedia';

const PRIVATE_IP_PATTERNS = [
  /^127\./,
  /^10\./,
  /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
  /^192\.168\./,
  /^169\.254\./,
  /^0\.0\.0\.0/,
  /^::1$/,
  /^fc00:/i,
  /^fe80:/i,
];

export function normalizeAndValidateUrl(input: string): URL {
  if (!input || typeof input !== 'string') {
    throw new Error('Please enter a valid web address or media link.');
  }

  let cleaned = input.trim();
  if (!cleaned.startsWith('http://') && !cleaned.startsWith('https://')) {
    cleaned = 'https://' + cleaned;
  }

  let parsed: URL;
  try {
    parsed = new URL(cleaned);
  } catch {
    throw new Error(`The provided address "${input}" is not a valid URL format.`);
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error(`Protocol "${parsed.protocol}" is not supported. Only HTTP and HTTPS are permitted.`);
  }

  const hostname = parsed.hostname.toLowerCase();
  if (
    hostname === 'localhost' ||
    hostname.endsWith('.localhost') ||
    hostname === '127.0.0.1' ||
    hostname === '::1'
  ) {
    throw new Error('Security Restriction (SSRF): Access to loopback/localhost is blocked.');
  }

  if (net.isIP(hostname)) {
    for (const pattern of PRIVATE_IP_PATTERNS) {
      if (pattern.test(hostname)) {
        throw new Error('Security Restriction (SSRF): Access to private and local network ranges is blocked.');
      }
    }
  }

  return parsed;
}

export async function routeAndAnalyzeUrl(
  rawUrl: string,
  userAgent: string
): Promise<PlatformAnalysisResult> {
  const validated = normalizeAndValidateUrl(rawUrl);
  const targetUrl = validated.href;

  if (isYouTubeUrl(targetUrl)) {
    return await handleYouTube(targetUrl);
  }

  if (isTikTokUrl(targetUrl)) {
    return await handleTikTok(targetUrl);
  }

  if (isInstagramUrl(targetUrl)) {
    return await handleInstagram(targetUrl);
  }

  if (isFacebookUrl(targetUrl)) {
    return await handleFacebook(targetUrl);
  }

  return await handleDirectOrGeneric(targetUrl, userAgent);
}
