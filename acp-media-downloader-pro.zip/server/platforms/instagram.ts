import { PlatformAnalysisResult, AnalyzedMediaItem } from './types';
import * as cheerio from 'cheerio';

export function isInstagramUrl(urlStr: string): boolean {
  try {
    const u = new URL(urlStr);
    const host = u.hostname.toLowerCase();
    return host.includes('instagram.com') || host === 'instagr.am';
  } catch {
    return false;
  }
}

export async function handleInstagram(urlStr: string): Promise<PlatformAnalysisResult> {
  const items: AnalyzedMediaItem[] = [];
  let pageTitle = 'Instagram Post';
  let thumbnail = '';
  let directMediaFound = false;

  try {
    // Perform request with realistic browser headers
    const res = await fetch(urlStr, {
      method: 'GET',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      redirect: 'manual', // Detect Instagram redirect to login
      signal: AbortSignal.timeout(8000),
    });

    // Check if Instagram redirected to login wall
    if (res.status === 301 || res.status === 302) {
      const location = res.headers.get('location') || '';
      if (location.includes('accounts/login') || location.includes('/login')) {
        return {
          success: false,
          platform: 'instagram',
          platformName: 'Instagram',
          isDirectMedia: false,
          pageTitle: 'Instagram Post (Login Required)',
          items: [],
          supportedDownloadMethods: ['Instagram Data Export', 'Meta Accounts Center'],
          requiresAuth: true,
          restrictionNotice:
            'Instagram Authentication Required: This content requires an active Instagram login session or belongs to a private profile. Meta’s platform policies prohibit anonymous scraping of non-public user media.',
          authHelp:
            'To download your own Instagram photos and Reels: go to Settings > Accounts Center > Your Information and Permissions > Download your information.',
        };
      }
    }

    if (res.ok) {
      const html = await res.text();
      const $ = cheerio.load(html);

      pageTitle = $('title').first().text().replace('• Instagram photos and videos', '').trim() || 'Instagram Media';
      const cleanTitle = pageTitle.replace(/[^a-zA-Z0-9_\-\s]/g, '').trim().slice(0, 45) || 'instagram_asset';

      // 1. Check for og:video (Reels or video post)
      const ogVideo = $('meta[property="og:video"]').attr('content') || $('meta[property="og:video:url"]').attr('content');
      if (ogVideo && ogVideo.startsWith('http')) {
        directMediaFound = true;
        items.push({
          id: `ig_vid_${Date.now()}`,
          type: 'video',
          url: ogVideo,
          filename: `${cleanTitle}.mp4`,
          format: 'MP4',
          resolution: 'Instagram HD',
          sourceContext: 'Instagram Public Reel/Video',
        });
      }

      // 2. Check for og:image
      const ogImage = $('meta[property="og:image"]').attr('content');
      if (ogImage && ogImage.startsWith('http')) {
        thumbnail = ogImage;
        items.push({
          id: `ig_img_${Date.now()}`,
          type: 'image',
          url: ogImage,
          filename: `${cleanTitle}.jpg`,
          format: 'JPG',
          resolution: 'Original Photo',
          sourceContext: 'Instagram Public Photo Asset',
        });
      }
    }
  } catch (err: any) {
    // Network or timeout
  }

  if (items.length > 0) {
    return {
      success: true,
      platform: 'instagram',
      platformName: 'Instagram',
      isDirectMedia: false,
      pageTitle,
      thumbnailUrl: thumbnail,
      items,
      supportedDownloadMethods: ['Public Instagram Media Extraction', 'Meta Data Archive'],
    };
  }

  return {
    success: false,
    platform: 'instagram',
    platformName: 'Instagram',
    isDirectMedia: false,
    pageTitle: 'Instagram Post',
    items: [],
    supportedDownloadMethods: ['Meta Accounts Center Official Archive'],
    requiresAuth: true,
    restrictionNotice:
      'Instagram Private / Restricted Post: This URL points to a private account, a temporary story, or requires an Instagram login session. Anonymous downloading is restricted by Instagram privacy controls.',
    authHelp:
      'For user-owned accounts: Request your complete official media archive from Meta Accounts Center (accountscenter.instagram.com).',
  };
}
