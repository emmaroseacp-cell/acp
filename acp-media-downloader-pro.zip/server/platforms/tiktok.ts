import { PlatformAnalysisResult, AnalyzedMediaItem } from './types';
import * as cheerio from 'cheerio';

export function isTikTokUrl(urlStr: string): boolean {
  try {
    const u = new URL(urlStr);
    const host = u.hostname.toLowerCase();
    return host.includes('tiktok.com');
  } catch {
    return false;
  }
}

export async function handleTikTok(urlStr: string): Promise<PlatformAnalysisResult> {
  const oembedUrl = `https://www.tiktok.com/oembed?url=${encodeURIComponent(urlStr)}`;

  let oembedData: any = null;
  try {
    const oembedRes = await fetch(oembedUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
      },
      signal: AbortSignal.timeout(8000),
    });

    if (oembedRes.ok) {
      oembedData = await oembedRes.json();
    }
  } catch {
    // Proceed to fallback
  }

  const title = oembedData?.title || 'TikTok Video';
  const author = oembedData?.author_name || 'TikTok Creator';
  const authorUrl = oembedData?.author_url || '';
  const thumbnail = oembedData?.thumbnail_url || '';

  const cleanTitle = title.replace(/[^a-zA-Z0-9_\-\s]/g, '').trim().slice(0, 45) || 'tiktok_video';
  const items: AnalyzedMediaItem[] = [];

  // Authorized cover image
  if (thumbnail) {
    items.push({
      id: `tt_thumb_${Date.now()}`,
      type: 'image',
      url: thumbnail,
      filename: `${cleanTitle}_cover.jpg`,
      format: 'JPG',
      resolution: 'Original Cover',
      sourceContext: 'TikTok Official Thumbnail',
    });
  }

  // Attempt to check if public authorized video stream is available
  let directVideoUrl: string | null = null;
  try {
    const pageRes = await fetch(urlStr, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        Referer: 'https://www.tiktok.com/',
      },
      signal: AbortSignal.timeout(8000),
    });

    if (pageRes.ok) {
      const html = await pageRes.text();
      const $ = cheerio.load(html);

      // Check OpenGraph video
      const ogVideo = $('meta[property="og:video"]').attr('content') || $('meta[property="og:video:url"]').attr('content');
      if (ogVideo && ogVideo.startsWith('http')) {
        directVideoUrl = ogVideo;
      }
    }
  } catch {
    // Page fetch may be restricted by TikTok CDN
  }

  if (directVideoUrl) {
    items.unshift({
      id: `tt_vid_${Date.now()}`,
      type: 'video',
      url: directVideoUrl,
      filename: `${cleanTitle}.mp4`,
      format: 'MP4',
      resolution: 'HD Stream',
      sourceContext: 'TikTok Public Video',
    });
  }

  return {
    success: true,
    platform: 'tiktok',
    platformName: 'TikTok',
    isDirectMedia: false,
    pageTitle: title,
    author,
    authorUrl,
    thumbnailUrl: thumbnail,
    items,
    supportedDownloadMethods: [
      'TikTok In-App "Save Video" (When permitted by creator)',
      'TikTok Official oEmbed Metadata',
      'Creator Web Studio Archive',
    ],
    restrictionNotice: directVideoUrl
      ? undefined
      : 'TikTok video stream is protected by the creator’s privacy settings or requires the in-app "Save Video" feature enabled by the author. The verified cover art is available below.',
    authHelp:
      'To download your own TikTok videos: open the TikTok app, tap Profile, select the video, tap the 3 dots (...) and choose "Save Video" or use TikTok Studio.',
  };
}
