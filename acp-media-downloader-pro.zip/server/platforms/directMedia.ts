import { PlatformAnalysisResult, AnalyzedMediaItem } from './types';
import path from 'path';
import * as cheerio from 'cheerio';

const DIRECT_MEDIA_EXTENSIONS = [
  'mp4',
  'webm',
  'mov',
  'mkv',
  'avi',
  'flv',
  'jpg',
  'jpeg',
  'png',
  'webp',
  'gif',
  'svg',
  'bmp',
  'mp3',
  'wav',
  'flac',
  'ogg',
  'aac',
  'pdf',
];

export function isDirectMediaExtension(urlStr: string): boolean {
  try {
    const u = new URL(urlStr);
    const pathname = u.pathname.toLowerCase();
    const ext = pathname.split('.').pop()?.split('?')[0] || '';
    return DIRECT_MEDIA_EXTENSIONS.includes(ext);
  } catch {
    return false;
  }
}

export function sanitizeFilename(input: string, fallback = 'download'): string {
  if (!input) return fallback;
  const basename = path.basename(input).split('?')[0].split('#')[0];
  const cleaned = basename.replace(/[^a-zA-Z0-9._-]/g, '_');
  return cleaned.length > 0 ? cleaned : fallback;
}

export async function handleDirectOrGeneric(
  urlStr: string,
  userAgent: string
): Promise<PlatformAnalysisResult> {
  const targetUrl = urlStr;

  // 1. Check HEAD request first to inspect Content-Type
  let headRes: globalThis.Response | null = null;
  try {
    headRes = await fetch(targetUrl, {
      method: 'HEAD',
      headers: { 'User-Agent': userAgent },
      signal: AbortSignal.timeout(6000),
    });
  } catch {
    // HEAD might not be supported; continue
  }

  const contentType = headRes?.headers.get('content-type')?.toLowerCase() || '';
  const contentLength = parseInt(headRes?.headers.get('content-length') || '0', 10);

  // Direct Image
  if (contentType.startsWith('image/')) {
    const ext = contentType.split('/')[1]?.split(';')[0] || 'jpg';
    const cleanName = sanitizeFilename(targetUrl, `image_${Date.now()}.${ext}`);
    const filename = cleanName.includes('.') ? cleanName : `${cleanName}.${ext}`;

    return {
      success: true,
      platform: 'direct',
      platformName: 'Direct Image File',
      isDirectMedia: true,
      pageTitle: filename,
      thumbnailUrl: targetUrl,
      items: [
        {
          id: `direct_img_${Date.now()}`,
          type: 'image',
          url: targetUrl,
          filename,
          format: ext.toUpperCase(),
          sizeBytes: contentLength > 0 ? contentLength : undefined,
          mimeType: contentType,
          resolution: 'Original Resolution',
          sourceContext: 'Direct Image Stream',
        },
      ],
      supportedDownloadMethods: ['Direct Stream Download (HTTP Chunked)', 'HTTP Range Resume'],
    };
  }

  // Direct Video
  if (contentType.startsWith('video/')) {
    const ext = contentType.split('/')[1]?.split(';')[0] || 'mp4';
    const cleanName = sanitizeFilename(targetUrl, `video_${Date.now()}.${ext}`);
    const filename = cleanName.includes('.') ? cleanName : `${cleanName}.${ext}`;

    return {
      success: true,
      platform: 'direct',
      platformName: 'Direct Video Stream',
      isDirectMedia: true,
      pageTitle: filename,
      items: [
        {
          id: `direct_vid_${Date.now()}`,
          type: 'video',
          url: targetUrl,
          filename,
          format: ext.toUpperCase(),
          sizeBytes: contentLength > 0 ? contentLength : undefined,
          mimeType: contentType,
          resolution: 'Native Video Stream',
          sourceContext: 'Direct Media Binary',
        },
      ],
      supportedDownloadMethods: ['Direct Stream Download (HTTP Chunked)', 'HTTP Range Resume'],
    };
  }

  // Direct Audio
  if (contentType.startsWith('audio/')) {
    const ext = contentType.split('/')[1]?.split(';')[0] || 'mp3';
    const cleanName = sanitizeFilename(targetUrl, `audio_${Date.now()}.${ext}`);
    const filename = cleanName.includes('.') ? cleanName : `${cleanName}.${ext}`;

    return {
      success: true,
      platform: 'direct',
      platformName: 'Direct Audio Stream',
      isDirectMedia: true,
      pageTitle: filename,
      items: [
        {
          id: `direct_aud_${Date.now()}`,
          type: 'audio',
          url: targetUrl,
          filename,
          format: ext.toUpperCase(),
          sizeBytes: contentLength > 0 ? contentLength : undefined,
          mimeType: contentType,
          resolution: 'Audio Bitstream',
          sourceContext: 'Direct Audio Binary',
        },
      ],
      supportedDownloadMethods: ['Direct Stream Download (HTTP Chunked)'],
    };
  }

  // If extension is direct media but server didn't respond to HEAD with media content-type:
  if (isDirectMediaExtension(targetUrl)) {
    const ext = targetUrl.split('.').pop()?.split('?')[0]?.toLowerCase() || 'mp4';
    const cleanName = sanitizeFilename(targetUrl, `media_${Date.now()}.${ext}`);
    const isVid = ['mp4', 'webm', 'mov', 'mkv', 'avi'].includes(ext);
    const isImg = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'].includes(ext);

    return {
      success: true,
      platform: 'direct',
      platformName: isVid ? 'Direct Video' : isImg ? 'Direct Image' : 'Direct Media File',
      isDirectMedia: true,
      pageTitle: cleanName,
      items: [
        {
          id: `direct_ext_${Date.now()}`,
          type: isVid ? 'video' : isImg ? 'image' : 'document',
          url: targetUrl,
          filename: cleanName,
          format: ext.toUpperCase(),
          resolution: 'Original File',
          sourceContext: 'Direct URL Endpoint',
        },
      ],
      supportedDownloadMethods: ['Direct Stream Download (HTTP Chunked)'],
    };
  }

  // Otherwise, it's a standard webpage: fetch HTML and extract public accessible media
  const htmlRes = await fetch(targetUrl, {
    method: 'GET',
    headers: {
      'User-Agent': userAgent,
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    },
    signal: AbortSignal.timeout(10000),
  });

  if (!htmlRes.ok) {
    throw new Error(`Target host responded with HTTP ${htmlRes.status} (${htmlRes.statusText}).`);
  }

  const html = await htmlRes.text();
  const $ = cheerio.load(html);
  const pageTitle = $('title').first().text().trim() || new URL(targetUrl).hostname;

  const items: AnalyzedMediaItem[] = [];
  const seenUrls = new Set<string>();

  const addMedia = (item: AnalyzedMediaItem) => {
    try {
      const fullUrl = new URL(item.url, targetUrl).href;
      if (!seenUrls.has(fullUrl)) {
        seenUrls.add(fullUrl);
        item.url = fullUrl;
        items.push(item);
      }
    } catch {
      // Skip invalid subresources
    }
  };

  // OpenGraph video
  const ogVideo = $('meta[property="og:video"]').attr('content') || $('meta[property="og:video:url"]').attr('content');
  if (ogVideo) {
    addMedia({
      id: `meta_vid_${items.length + 1}`,
      type: 'video',
      url: ogVideo,
      filename: sanitizeFilename(ogVideo, `${pageTitle.slice(0, 30)}_video.mp4`),
      format: 'MP4',
      resolution: 'High Definition',
      sourceContext: 'OpenGraph Video Tag',
    });
  }

  // OpenGraph image
  const ogImage = $('meta[property="og:image"]').attr('content') || $('meta[name="twitter:image"]').attr('content');
  if (ogImage) {
    addMedia({
      id: `meta_img_${items.length + 1}`,
      type: 'image',
      url: ogImage,
      filename: sanitizeFilename(ogImage, `${pageTitle.slice(0, 30)}_cover.jpg`),
      format: 'JPG/WebP',
      resolution: 'Hero Image',
      sourceContext: 'Social Metadata Asset',
    });
  }

  // Video tags
  $('video, video source').each((_, el) => {
    const src = $(el).attr('src') || $(el).attr('data-src');
    if (src && !src.startsWith('blob:')) {
      const ext = src.split('.').pop()?.split('?')[0]?.toLowerCase() || 'mp4';
      addMedia({
        id: `vid_${items.length + 1}`,
        type: 'video',
        url: src,
        filename: sanitizeFilename(src, `video_${items.length + 1}.${ext}`),
        format: ext.toUpperCase(),
        resolution: 'HTML5 Video',
        sourceContext: 'HTML5 Video Stream',
      });
    }
  });

  // Images
  $('img').each((_, el) => {
    const src = $(el).attr('src') || $(el).attr('data-src');
    if (src && !src.startsWith('data:') && !src.startsWith('blob:')) {
      const ext = src.split('.').pop()?.split('?')[0]?.toLowerCase() || 'jpg';
      const alt = $(el).attr('alt') || $(el).attr('title') || '';
      addMedia({
        id: `img_${items.length + 1}`,
        type: 'image',
        url: src,
        filename: sanitizeFilename(alt || src, `image_${items.length + 1}.${ext}`),
        format: ext.toUpperCase(),
        resolution: 'Page Graphic',
        sourceContext: alt ? `Alt: ${alt.slice(0, 30)}` : 'Inline Image',
      });
    }
  });

  return {
    success: items.length > 0,
    platform: 'generic',
    platformName: 'Public Web Page',
    isDirectMedia: false,
    pageTitle,
    items: items.slice(0, 50),
    supportedDownloadMethods: ['HTML5 Media Extraction', 'HTTP Range Stream'],
    restrictionNotice:
      items.length === 0 ? 'No public image or video assets were detected on this webpage.' : undefined,
  };
}
