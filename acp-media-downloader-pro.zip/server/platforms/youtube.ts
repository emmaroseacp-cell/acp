import { PlatformAnalysisResult, AnalyzedMediaItem } from './types';

export function isYouTubeUrl(urlStr: string): boolean {
  try {
    const u = new URL(urlStr);
    const host = u.hostname.toLowerCase();
    return (
      host === 'www.youtube.com' ||
      host === 'youtube.com' ||
      host === 'm.youtube.com' ||
      host === 'youtu.be' ||
      host.endsWith('.youtube.com')
    );
  } catch {
    return false;
  }
}

export function extractYouTubeVideoId(urlStr: string): string | null {
  try {
    const u = new URL(urlStr);
    if (u.hostname.toLowerCase() === 'youtu.be') {
      return u.pathname.slice(1).split('/')[0].split('?')[0];
    }
    if (u.pathname.startsWith('/shorts/')) {
      return u.pathname.split('/shorts/')[1].split('/')[0].split('?')[0];
    }
    if (u.pathname.startsWith('/embed/')) {
      return u.pathname.split('/embed/')[1].split('/')[0].split('?')[0];
    }
    return u.searchParams.get('v');
  } catch {
    return null;
  }
}

export async function handleYouTube(urlStr: string): Promise<PlatformAnalysisResult> {
  const videoId = extractYouTubeVideoId(urlStr);

  if (!videoId) {
    return {
      success: false,
      platform: 'youtube',
      platformName: 'YouTube',
      isDirectMedia: false,
      pageTitle: 'YouTube Video',
      items: [],
      supportedDownloadMethods: ['YouTube Studio Export', 'oEmbed Metadata'],
      restrictionNotice: 'Could not parse a valid YouTube Video ID from the provided URL.',
    };
  }

  const canonicalUrl = `https://www.youtube.com/watch?v=${videoId}`;
  const oembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(canonicalUrl)}&format=json`;

  let oembedData: any = null;
  try {
    const oembedRes = await fetch(oembedUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
      },
      signal: AbortSignal.timeout(8000),
    });

    if (oembedRes.ok) {
      oembedData = await oembedRes.json();
    } else if (oembedRes.status === 404) {
      return {
        success: false,
        platform: 'youtube',
        platformName: 'YouTube',
        isDirectMedia: false,
        pageTitle: 'YouTube Video (Unavailable)',
        items: [],
        supportedDownloadMethods: ['YouTube Studio'],
        restrictionNotice: 'This YouTube video is private, deleted, or region-restricted.',
        requiresAuth: true,
      };
    }
  } catch {
    // Proceed with fallback videoId assets
  }

  const title = oembedData?.title || `YouTube Video (${videoId})`;
  const author = oembedData?.author_name || 'YouTube Creator';
  const authorUrl = oembedData?.author_url || '';

  const cleanTitle = title.replace(/[^a-zA-Z0-9_\-\s]/g, '').trim().slice(0, 50);

  // Authorized assets
  const items: AnalyzedMediaItem[] = [];

  // 1. High Resolution Thumbnail (MaxRes 1080p / HQ) - fully authorized by YouTube oEmbed
  const maxResThumb = `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`;
  const hqThumb = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;

  items.push({
    id: `yt_thumb_max_${videoId}`,
    type: 'image',
    url: maxResThumb,
    filename: `${cleanTitle}_thumbnail_1080p.jpg`,
    format: 'JPG',
    resolution: '1920x1080 (MaxRes)',
    sourceContext: 'YouTube Official Master Artwork',
  });

  items.push({
    id: `yt_thumb_hq_${videoId}`,
    type: 'image',
    url: hqThumb,
    filename: `${cleanTitle}_thumbnail_hq.jpg`,
    format: 'JPG',
    resolution: '480x360 (HQ Standard)',
    sourceContext: 'YouTube Official Thumbnail',
  });

  return {
    success: true,
    platform: 'youtube',
    platformName: 'YouTube',
    isDirectMedia: false,
    pageTitle: title,
    author,
    authorUrl,
    thumbnailUrl: hqThumb,
    items,
    supportedDownloadMethods: [
      'Official YouTube oEmbed Artwork & Metadata',
      'YouTube Studio MP4 Original Export (For creator-owned media)',
      'YouTube App Authorized Offline Cache',
    ],
    restrictionNotice:
      'Direct raw video stream extraction for YouTube videos is restricted by YouTube Terms of Service. For user-owned content, you can download your original MP4 via YouTube Studio > Content > Download. Authorized high-resolution cover art is available below.',
    authHelp:
      'If you own this video: sign into YouTube Studio (studio.youtube.com), select Content, click the three dots beside your video, and select Download.',
  };
}
