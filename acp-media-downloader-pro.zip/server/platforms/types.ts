export type PlatformType = 'youtube' | 'tiktok' | 'instagram' | 'facebook' | 'direct' | 'generic';

export interface AnalyzedMediaItem {
  id: string;
  type: 'image' | 'video' | 'audio' | 'document';
  url: string;
  filename: string;
  format: string;
  sizeBytes?: number;
  mimeType?: string;
  resolution?: string;
  sourceContext?: string;
  requiresHeaders?: Record<string, string>;
  isStreamOnly?: boolean;
}

export interface PlatformAnalysisResult {
  success: boolean;
  platform: PlatformType;
  platformName: string;
  isDirectMedia: boolean;
  pageTitle: string;
  author?: string;
  authorUrl?: string;
  thumbnailUrl?: string;
  items: AnalyzedMediaItem[];
  supportedDownloadMethods: string[];
  restrictionNotice?: string;
  requiresAuth?: boolean;
  authHelp?: string;
  warning?: string;
  duration?: string;
}
