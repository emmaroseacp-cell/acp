import { PlatformAnalysisResult, AnalyzedMediaItem } from './types';
import * as cheerio from 'cheerio';
import { normalizeAndValidateUrl } from './platformManager';

export function isFacebookUrl(urlStr: string): boolean {
  try {
    const u = new URL(urlStr);
    const host = u.hostname.toLowerCase();
    return (
      host === 'facebook.com' ||
      host.endsWith('.facebook.com') ||
      host === 'fb.watch' ||
      host.endsWith('.fb.watch') ||
      host === 'fb.com' ||
      host.endsWith('.fb.com')
    );
  } catch {
    return false;
  }
}

function cleanStreamUrl(rawUrl: string): string {
  return rawUrl.replace(/\\\//g, '/').replace(/\\u0026/g, '&').replace(/&amp;/g, '&');
}

function sanitizeLogUrl(urlStr: string): string {
  try {
    const u = new URL(urlStr);
    return `${u.protocol}//${u.host}${u.pathname}`;
  } catch {
    return urlStr.slice(0, 60);
  }
}

export async function handleFacebook(urlStr: string): Promise<PlatformAnalysisResult> {
  const sanitizedInput = sanitizeLogUrl(urlStr);
  console.log(`[Facebook Inspector] [Stage: Input] Processing Facebook URL: ${sanitizedInput}`);

  // 1. Normalize Facebook URL
  let targetUrl = urlStr.trim();
  try {
    const parsed = new URL(targetUrl.startsWith('http') ? targetUrl : 'https://' + targetUrl);
    // Prefer desktop endpoint for server-side HTML rendering
    if (parsed.hostname === 'm.facebook.com' || parsed.hostname === 'mobile.facebook.com') {
      parsed.hostname = 'www.facebook.com';
      targetUrl = parsed.href;
    }
  } catch {
    console.warn(`[Facebook Inspector] [Stage: Validation] Malformed URL format: ${sanitizedInput}`);
    return {
      success: false,
      platform: 'facebook',
      platformName: 'Facebook',
      isDirectMedia: false,
      pageTitle: 'Invalid Facebook URL',
      items: [],
      supportedDownloadMethods: [],
      restrictionNotice:
        'The provided address is not a valid Facebook URL. Please check the link format (e.g. facebook.com/watch?v=... or fb.watch/...).',
    };
  }

  // 2. Fetch page with authentic desktop browser headers and follow redirects
  let pageRes: globalThis.Response;
  let finalUrl = targetUrl;
  try {
    console.log(`[Facebook Inspector] [Stage: Dispatch] Fetching page with desktop navigation headers...`);
    pageRes = await fetch(targetUrl, {
      method: 'GET',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
      },
      redirect: 'follow',
      signal: AbortSignal.timeout(12000), // 12s timeout
    });

    finalUrl = pageRes.url;
    console.log(
      `[Facebook Inspector] [Stage: Response] Received HTTP status: ${pageRes.status} | Final URL: ${sanitizeLogUrl(
        finalUrl
      )}`
    );
  } catch (netErr: any) {
    console.error(`[Facebook Inspector] [Stage: Network Failure] Error fetching URL: ${netErr.message}`);
    const isTimeout = netErr.name === 'TimeoutError' || netErr.message?.includes('timeout');
    return {
      success: false,
      platform: 'facebook',
      platformName: 'Facebook',
      isDirectMedia: false,
      pageTitle: 'Facebook Connection Error',
      items: [],
      supportedDownloadMethods: ['Facebook Desktop Download', 'Meta Accounts Archive'],
      restrictionNotice: isTimeout
        ? 'Connection to Facebook timed out. Facebook servers may be rate-limiting or experiencing network latency. Please retry shortly.'
        : `Network connection to Facebook failed (${netErr.message}). Please verify your internet connection.`,
    };
  }

  // 3. Inspect final URL for login redirects
  const isLoginRedirect =
    finalUrl.includes('/login') ||
    finalUrl.includes('/checkpoint') ||
    finalUrl.includes('login.php') ||
    finalUrl.includes('/recover/');

  if (isLoginRedirect) {
    console.log(`[Facebook Inspector] [Stage: Access Wall] Detected redirect to login checkpoint: ${sanitizeLogUrl(finalUrl)}`);
    return {
      success: false,
      platform: 'facebook',
      platformName: 'Facebook',
      isDirectMedia: false,
      pageTitle: 'Facebook Video (Login Required)',
      items: [],
      supportedDownloadMethods: ['Facebook Official Download', 'Meta Accounts Center'],
      requiresAuth: true,
      restrictionNotice:
        'Facebook Authentication Required: This video belongs to a private profile, is shared exclusively with a closed group/friends, or requires an active Facebook login session. Meta security policies prohibit unauthenticated public scraping of non-public media.',
      authHelp:
        'To download your own video or content you have access to: open Facebook on desktop, navigate to the video post, click the three dots (...) and select "Download video". Or request your complete account archive from Settings > Your Facebook Information > Download Profile Information.',
    };
  }

  // Handle specific non-200 HTTP statuses
  if (pageRes.status === 404) {
    console.log(`[Facebook Inspector] [Stage: Not Found] HTTP 404 received for ${sanitizedInput}`);
    return {
      success: false,
      platform: 'facebook',
      platformName: 'Facebook',
      isDirectMedia: false,
      pageTitle: 'Facebook Video (Not Found)',
      items: [],
      supportedDownloadMethods: [],
      restrictionNotice:
        'This Facebook video was not found (HTTP 404). It may have been removed, deleted by the author, or the link may be mistyped.',
    };
  }

  if (pageRes.status === 403) {
    console.log(`[Facebook Inspector] [Stage: Forbidden] HTTP 403 received for ${sanitizedInput}`);
    return {
      success: false,
      platform: 'facebook',
      platformName: 'Facebook',
      isDirectMedia: false,
      pageTitle: 'Facebook Access Denied',
      items: [],
      supportedDownloadMethods: ['Facebook Official Download'],
      restrictionNotice:
        'Access Denied (HTTP 403): The Facebook host restricted access to this resource. This typically occurs when content is geo-blocked or restricted to registered accounts.',
    };
  }

  // 4. Parse HTML and search for public video stream URLs
  const html = await pageRes.text();
  const $ = cheerio.load(html);

  // Check if Facebook returned the standard private/deleted text in page body
  const bodyText = $('body').text();
  const hasPrivatePhrase =
    bodyText.includes("This content isn't available right now") ||
    bodyText.includes("When this happens, it's usually because the owner only shared it with a small group of people") ||
    bodyText.includes("This page isn't available") ||
    bodyText.includes("You must log in to continue");

  if (hasPrivatePhrase && !html.includes('browser_native_hd_url') && !html.includes('browser_native_sd_url')) {
    console.log(`[Facebook Inspector] [Stage: Content Restriction] Detected Facebook privacy phrase in body text`);
    return {
      success: false,
      platform: 'facebook',
      platformName: 'Facebook',
      isDirectMedia: false,
      pageTitle: 'Facebook Content Unavailable',
      items: [],
      supportedDownloadMethods: ['Facebook Official Download', 'Meta Data Archive'],
      requiresAuth: true,
      restrictionNotice:
        'Facebook Content Unavailable: The author has restricted this video to a private audience, or the video has been deleted. Facebook does not permit public downloading of non-public posts.',
      authHelp:
        'For videos you own: log into Facebook on desktop, click the 3 dots (...) on your post, and select "Download video".',
    };
  }

  // Extract page title
  let pageTitle = $('title').first().text().replace(/\s*\|\s*Facebook/i, '').trim();
  if (!pageTitle || pageTitle === 'Facebook' || pageTitle === 'Log in to Facebook') {
    const metaTitle = $('meta[property="og:title"]').attr('content');
    pageTitle = metaTitle?.trim() || 'Facebook Video';
  }

  const cleanTitle = pageTitle.replace(/[^a-zA-Z0-9_\-\s]/g, '').trim().slice(0, 45) || 'facebook_video';

  const items: AnalyzedMediaItem[] = [];
  const seenUrls = new Set<string>();

  const addStream = (url: string, quality: string, format = 'MP4', isHD = false) => {
    try {
      const cleanUrl = cleanStreamUrl(url);
      if (!cleanUrl.startsWith('http')) return;
      if (seenUrls.has(cleanUrl)) return;
      seenUrls.add(cleanUrl);

      items.push({
        id: `fb_vid_${isHD ? 'hd' : 'sd'}_${items.length + 1}`,
        type: 'video',
        url: cleanUrl,
        filename: `${cleanTitle}_${isHD ? 'HD' : 'SD'}.mp4`,
        format,
        resolution: isHD ? '1080p / 720p HD' : '480p / 360p Standard',
        sourceContext: `Facebook ${isHD ? 'High-Definition' : 'Standard'} Video Stream`,
      });
    } catch {
      // Skip malformed stream URL
    }
  };

  // 4A. Search for browser_native_hd_url and browser_native_sd_url (Facebook desktop HTML)
  const hdMatch =
    /browser_native_hd_url["']\s*:\s*["']([^"']+)["']/.exec(html) ||
    /playable_url_quality_hd["']\s*:\s*["']([^"']+)["']/.exec(html) ||
    /hd_src["']\s*:\s*["']([^"']+)["']/.exec(html);

  const sdMatch =
    /browser_native_sd_url["']\s*:\s*["']([^"']+)["']/.exec(html) ||
    /playable_url["']\s*:\s*["']([^"']+)["']/.exec(html) ||
    /sd_src["']\s*:\s*["']([^"']+)["']/.exec(html);

  if (hdMatch && hdMatch[1]) {
    addStream(hdMatch[1], '1080p/720p HD', 'MP4', true);
  }

  if (sdMatch && sdMatch[1]) {
    addStream(sdMatch[1], '480p/360p SD', 'MP4', false);
  }

  // 4B. Check OpenGraph video fallback
  const ogVideo = $('meta[property="og:video"]').attr('content') || $('meta[property="og:video:url"]').attr('content');
  if (ogVideo && ogVideo.startsWith('http')) {
    addStream(ogVideo, 'Standard MP4', 'MP4', false);
  }

  // 4C. Check generic video CDN matches if above patterns missed
  if (items.length === 0) {
    const rawMp4Matches = html.match(/https:\\\/\\\/[^"']+\.mp4[^"']*/g) || [];
    for (const raw of rawMp4Matches.slice(0, 2)) {
      const decoded = cleanStreamUrl(raw);
      if (decoded.includes('fbcdn.net') || decoded.includes('facebook.com')) {
        addStream(decoded, 'MP4 Video Stream', 'MP4', decoded.includes('hd') || decoded.includes('quality_hd'));
      }
    }
  }

  // 4D. Check for cover image / thumbnail
  let thumbnail = $('meta[property="og:image"]').attr('content') || '';
  if (!thumbnail) {
    const thumbMatch = /preferred_thumbnail["']\s*:\s*["']([^"']+)["']/.exec(html);
    if (thumbMatch && thumbMatch[1]) {
      thumbnail = cleanStreamUrl(thumbMatch[1]);
    }
  }

  if (thumbnail && thumbnail.startsWith('http')) {
    items.push({
      id: `fb_thumb_${Date.now()}`,
      type: 'image',
      url: cleanStreamUrl(thumbnail),
      filename: `${cleanTitle}_cover.jpg`,
      format: 'JPG',
      resolution: 'Video Cover Art',
      sourceContext: 'Facebook Official Poster Image',
    });
  }

  console.log(
    `[Facebook Inspector] [Stage: Extraction Result] Found ${items.filter((i) => i.type === 'video').length} video stream(s) and ${
      items.filter((i) => i.type === 'image').length
    } image(s)`
  );

  // If video streams were successfully extracted
  if (items.length > 0) {
    return {
      success: true,
      platform: 'facebook',
      platformName: 'Facebook',
      isDirectMedia: false,
      pageTitle,
      thumbnailUrl: thumbnail || undefined,
      items,
      supportedDownloadMethods: ['Facebook Public Media Extraction', 'Direct Stream (HTTP Range)'],
    };
  }

  // If request succeeded (HTTP 200) but no direct streams could be scraped from the public shell
  console.log(`[Facebook Inspector] [Stage: Unextractable] Status 200 but no playable streams found`);
  return {
    success: false,
    platform: 'facebook',
    platformName: 'Facebook',
    isDirectMedia: false,
    pageTitle,
    items: [],
    supportedDownloadMethods: ['Facebook Desktop Native Download', 'Meta Accounts Archive'],
    restrictionNotice:
      'No public video streams could be extracted from this Facebook link. This may be an image post, an interactive live broadcast, or a post where Facebook requires viewing directly on the platform.',
    authHelp:
      'For content you posted on Facebook: open Facebook in your browser, click the 3 dots (...) on the post and click "Download video", or export your account media from Settings > Download Profile Information.',
  };
}
