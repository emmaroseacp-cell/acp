import React, { useState } from 'react';
import { Minus, Square, Copy, X } from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';

export const TitleBar: React.FC = () => {
  const [isMaximized, setIsMaximized] = useState(false);
  const { activeDownloads, systemMetrics } = useDownloadEngine();

  const downloadingCount = activeDownloads.filter((t) => t.status === 'downloading').length;
  const speedMb = (systemMetrics.currentSpeedBps / (1024 * 1024)).toFixed(1);

  const toggleMaximize = () => {
    setIsMaximized(!isMaximized);
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  return (
    <header className="h-9 bg-[#040814] border-b border-[#142344] flex items-center justify-between px-3 text-xs select-none window-drag-region shrink-0 z-50">
      {/* Brand Zone */}
      <div className="flex items-center gap-2.5 window-no-drag">
        <div className="w-5 h-5 rounded bg-gradient-to-br from-[#00E5FF] to-[#0284c7] p-0.5 flex items-center justify-center shadow-sm shadow-[#00E5FF]/20">
          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none">
            <path
              d="M4 18L10 6L16 18M7 14H13"
              stroke="#040814"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M15 10C15 8 16.5 6.5 18.5 6.5H20"
              stroke="#040814"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            <path
              d="M15 14C15 16 16.5 17.5 18.5 17.5H20"
              stroke="#040814"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          </svg>
        </div>
        <span className="font-bold text-slate-100 tracking-wide text-[11px] whitespace-nowrap">
          ACP MEDIA DOWNLOADER PRO
        </span>
        <span className="text-[10px] text-slate-500 font-mono hidden sm:inline">v1.0.0 · Win11 x64</span>
      </div>

      {/* Middle Status / Activity */}
      <div className="hidden md:flex items-center gap-2 text-slate-400 text-[11px] font-mono tabular-nums">
        {downloadingCount > 0 ? (
          <div className="flex items-center gap-2 px-2.5 py-0.5 rounded bg-[#0a1733] border border-[#1b315e] text-[#00E5FF]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] animate-ping" />
            <span>
              {downloadingCount} Active {downloadingCount === 1 ? 'Stream' : 'Streams'} ({speedMb} MB/s)
            </span>
          </div>
        ) : (
          <span className="text-slate-500">Ready for URL input</span>
        )}
      </div>

      {/* Windows Window Controls */}
      <div className="flex items-center -mr-3 window-no-drag h-full">
        <button
          onClick={() => {}}
          title="Minimize to Windows Taskbar"
          className="w-11 h-9 inline-flex items-center justify-center text-slate-400 hover:text-white hover:bg-[#111e38] transition-colors"
        >
          <Minus className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={toggleMaximize}
          title={isMaximized ? 'Restore Down' : 'Maximize'}
          className="w-11 h-9 inline-flex items-center justify-center text-slate-400 hover:text-white hover:bg-[#111e38] transition-colors"
        >
          {isMaximized ? <Copy className="w-3 h-3" /> : <Square className="w-3 h-3" />}
        </button>
        <button
          onClick={() => {}}
          title="Close ACP Media Downloader Pro"
          className="w-11 h-9 inline-flex items-center justify-center text-slate-400 hover:text-white hover:bg-[#dc2626] transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
