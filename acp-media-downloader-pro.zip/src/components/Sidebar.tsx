import React from 'react';
import {
  LayoutDashboard,
  Globe,
  Image,
  Video,
  Layers,
  ArrowDownToLine,
  History,
  Settings,
  Info,
  HardDrive,
  ShieldCheck,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';
import { NavigationPage } from '../types';

interface NavItem {
  id: NavigationPage;
  label: string;
  icon: React.ElementType;
  badge?: number;
}

export const Sidebar: React.FC = () => {
  const { currentPage, setCurrentPage, activeDownloads, settings } = useDownloadEngine();

  const downloadingCount = activeDownloads.filter((t) => t.status === 'downloading' || t.status === 'queued').length;

  const navItems: NavItem[] = [
    { id: 'home', label: 'Home Dashboard', icon: LayoutDashboard },
    { id: 'universal', label: 'Universal Downloader', icon: Globe },
    { id: 'images', label: 'Image Downloader', icon: Image },
    { id: 'videos', label: 'Video Downloader', icon: Video },
    { id: 'batch', label: 'Batch Downloader', icon: Layers },
    { id: 'manager', label: 'Download Manager', icon: ArrowDownToLine, badge: downloadingCount > 0 ? downloadingCount : undefined },
    { id: 'history', label: 'Download History', icon: History },
    { id: 'settings', label: 'Settings', icon: Settings },
    { id: 'about', label: 'About ACP Pro', icon: Info },
  ];

  return (
    <aside className="w-64 bg-[#050B18] border-r border-[#142344] flex flex-col justify-between select-none shrink-0">
      {/* Top Header / Branding */}
      <div>
        <div className="p-4 border-b border-[#142344] flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#00E5FF] to-[#0369a1] p-1 flex items-center justify-center shadow-lg shadow-[#00E5FF]/20">
            <span className="font-extrabold text-[#050B18] text-sm tracking-tighter">ACP</span>
          </div>
          <div>
            <div className="font-bold text-sm text-slate-100 tracking-tight leading-none">
              Media Downloader
            </div>
            <div className="text-[11px] text-[#00E5FF] font-semibold tracking-wider mt-1 flex items-center gap-1.5">
              <span>PRO EDITION</span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400 font-mono text-[10px]">v1.0</span>
            </div>
          </div>
        </div>

        {/* Navigation List */}
        <nav className="p-2.5 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-[#0e214d] to-[#0a1838] text-[#00E5FF] font-semibold border border-[#1b3a7a] shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#0a1329]'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#00E5FF]' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="bg-[#00E5FF] text-[#050B18] text-[10px] font-bold px-1.5 py-0.2 rounded-full tabular-nums">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* System Storage & Security Indicator */}
      <div className="p-3 m-2.5 rounded-lg bg-[#071024] border border-[#142344] text-[11px]">
        <div className="flex items-center justify-between text-slate-400 mb-2">
          <div className="flex items-center gap-1.5 font-medium text-slate-300">
            <HardDrive className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span>Target Drive</span>
          </div>
          <span className="text-[10px] text-emerald-400 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" />
            Protected
          </span>
        </div>
        <div className="text-[10px] font-mono text-slate-400 truncate bg-[#040814] p-1.5 rounded border border-[#0f1d38]">
          {settings.downloadDirectory}
        </div>
        <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-[#0e1d3b] text-[10px] text-slate-400">
          <span>Concurrency: {settings.maxConcurrent} streams</span>
          <span className="text-[#00E5FF] font-medium">SQLite Active</span>
        </div>
      </div>
    </aside>
  );
};
