export type MediaType = 'image' | 'video' | 'audio' | 'document';

export type PlatformType = 'youtube' | 'tiktok' | 'instagram' | 'facebook' | 'direct' | 'generic';

export interface AnalyzedMediaItem {
  id: string;
  type: MediaType;
  url: string;
  filename: string;
  format: string;
  sizeBytes?: number;
  mimeType?: string;
  resolution?: string;
  sourceContext?: string;
  isStreamOnly?: boolean;
}

export interface PlatformAnalysisResult {
  success: boolean;
  platform: PlatformType;
  platformName: string;
  isDirectMedia: boolean;
  pageTitle: string;
  author?: string;
  authorUrl?: string;
  thumbnailUrl?: string;
  items: AnalyzedMediaItem[];
  supportedDownloadMethods: string[];
  restrictionNotice?: string;
  requiresAuth?: boolean;
  authHelp?: string;
  warning?: string;
  error?: string;
  duration?: string;
}

export type DownloadStatus = 'queued' | 'downloading' | 'paused' | 'completed' | 'failed' | 'cancelled';

export interface DownloadTask {
  id: string;
  url: string;
  filename: string;
  type: MediaType;
  fileSize: number; // in bytes, 0 if unknown
  downloadedBytes: number;
  progress: number; // 0-100
  speed: number; // bytes/sec
  eta: number; // seconds
  status: DownloadStatus;
  startedAt: number;
  completedAt?: number;
  errorMessage?: string;
  blobUrl?: string;
  savePath: string;
}

export interface DownloadHistoryItem {
  id: string;
  url: string;
  filename: string;
  type: MediaType;
  fileSize: number;
  status: 'completed' | 'failed' | 'cancelled';
  completedAt: string;
  savePath: string;
  downloadDurationSec: number;
  errorMessage?: string;
}

export interface AppSettings {
  downloadDirectory: string;
  maxConcurrent: number;
  notifications: boolean;
  theme: 'navy' | 'slate';
  autoOpenFolder: boolean;
  networkTimeout: number;
  userAgent: string;
  preventDuplicates: boolean;
}

export type NavigationPage =
  | 'home'
  | 'universal'
  | 'images'
  | 'videos'
  | 'batch'
  | 'manager'
  | 'history'
  | 'settings'
  | 'about';
