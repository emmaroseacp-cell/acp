import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react';
import JSZip from 'jszip';
import {
  AnalyzedMediaItem,
  AppSettings,
  DownloadHistoryItem,
  DownloadStatus,
  DownloadTask,
  MediaType,
  NavigationPage,
  PlatformAnalysisResult,
} from '../types';

interface ToastNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: number;
}

interface DownloadEngineContextType {
  activeDownloads: DownloadTask[];
  history: DownloadHistoryItem[];
  settings: AppSettings;
  currentPage: NavigationPage;
  setCurrentPage: (page: NavigationPage) => void;
  toasts: ToastNotification[];
  removeToast: (id: string) => void;
  showToast: (title: string, message: string, type?: ToastNotification['type']) => void;
  analyzeUrl: (url: string) => Promise<PlatformAnalysisResult>;
  enqueueDownload: (url: string, filename: string, type?: MediaType, initialSize?: number) => string;
  enqueueBatchDownloads: (items: { url: string; filename: string; type?: MediaType; size?: number }[]) => void;
  pauseDownload: (id: string) => void;
  resumeDownload: (id: string) => void;
  cancelDownload: (id: string) => void;
  retryDownload: (id: string) => void;
  clearCompletedDownloads: () => void;
  clearHistory: () => void;
  deleteHistoryItem: (id: string) => void;
  updateSettings: (partial: Partial<AppSettings>) => void;
  exportHistory: (format: 'json' | 'csv') => void;
  downloadAsZip: (items: { url: string; filename: string }[], zipName?: string) => Promise<void>;
  saveBlobToDisk: (blobUrl: string, filename: string) => void;
  systemMetrics: {
    totalBytesDownloaded: number;
    completedCount: number;
    failedCount: number;
    currentSpeedBps: number;
  };
}

const DEFAULT_SETTINGS: AppSettings = {
  downloadDirectory: 'C:\\Users\\Default\\Downloads\\ACP Media',
  maxConcurrent: 3,
  notifications: true,
  theme: 'navy',
  autoOpenFolder: false,
  networkTimeout: 30000,
  userAgent: 'Chrome 128 (Windows 11)',
  preventDuplicates: true,
};

const DownloadEngineContext = createContext<DownloadEngineContextType | null>(null);

const STORAGE_KEY_HISTORY = 'acp_media_downloader_history_v1';
const STORAGE_KEY_SETTINGS = 'acp_media_downloader_settings_v1';

export const DownloadEngineProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tasks, setTasks] = useState<Map<string, DownloadTask>>(new Map());
  const [history, setHistory] = useState<DownloadHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_HISTORY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  const [currentPage, setCurrentPage] = useState<NavigationPage>('home');
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Internal references to active stream controllers & byte chunks
  const abortControllers = useRef<Map<string, AbortController>>(new Map());
  const chunkBuffers = useRef<Map<string, Uint8Array[]>>(new Map());
  const speedSamplers = useRef<Map<string, { lastBytes: number; lastTime: number }>>(new Map());

  // Save history to storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(history));
    } catch (e) {
      console.error('Failed to save download history:', e);
    }
  }, [history]);

  // Save settings to storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings:', e);
    }
  }, [settings]);

  const showToast = useCallback(
    (title: string, message: string, type: ToastNotification['type'] = 'info') => {
      if (!settings.notifications && type !== 'error') return;
      const toast: ToastNotification = {
        id: `toast_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        title,
        message,
        type,
        timestamp: Date.now(),
      };
      setToasts((prev) => [toast, ...prev].slice(0, 5));
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== toast.id));
      }, 5000);
    },
    [settings.notifications]
  );

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const saveBlobToDisk = useCallback((blobUrl: string, filename: string) => {
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }, []);

  // Centralized URL analyzer
  const analyzeUrl = useCallback(async (url: string): Promise<PlatformAnalysisResult> => {
    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: url.trim() }),
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(errText || `Server returned error status ${res.status}`);
    }

    return await res.json();
  }, []);

  // Real download worker for a single task
  const runDownload = useCallback(
    async (taskId: string) => {
      setTasks((prev) => {
        const t = prev.get(taskId);
        if (!t) return prev;
        const next = new Map(prev);
        next.set(taskId, { ...t, status: 'downloading', errorMessage: undefined });
        return next;
      });

      const currentTask = tasks.get(taskId);
      if (!currentTask) return;

      const controller = new AbortController();
      abortControllers.current.set(taskId, controller);

      const existingChunks = chunkBuffers.current.get(taskId) || [];
      chunkBuffers.current.set(taskId, existingChunks);

      let downloadedSoFar = existingChunks.reduce((acc, chunk) => acc + chunk.length, 0);

      try {
        const proxyUrl = `/api/proxy-download?url=${encodeURIComponent(currentTask.url)}&filename=${encodeURIComponent(
          currentTask.filename
        )}`;

        const headers: Record<string, string> = {};
        if (downloadedSoFar > 0) {
          headers['Range'] = `bytes=${downloadedSoFar}-`;
        }

        const response = await fetch(proxyUrl, {
          method: 'GET',
          headers,
          signal: controller.signal,
        });

        if (!response.ok && response.status !== 206) {
          const errBody = await response.text().catch(() => '');
          throw new Error(errBody || `Download server responded with HTTP ${response.status}`);
        }

        // If server does not support Range requests and returned 200, clear pre-existing chunks
        if (response.status === 200 && downloadedSoFar > 0) {
          existingChunks.length = 0;
          downloadedSoFar = 0;
        }

        const contentType = response.headers.get('content-type') || '';
        if (contentType.includes('text/html') && !currentTask.filename.endsWith('.html')) {
          throw new Error(
            'The remote host returned an HTML webpage (e.g. login wall or error page) instead of media stream.'
          );
        }

        const contentLengthHeader = response.headers.get('content-length');
        let totalBytes = currentTask.fileSize;

        if (contentLengthHeader) {
          const streamLen = parseInt(contentLengthHeader, 10);
          totalBytes = response.status === 206 ? downloadedSoFar + streamLen : streamLen;
        }

        const reader = response.body?.getReader();
        if (!reader) {
          throw new Error('Unable to read incoming stream data.');
        }

        speedSamplers.current.set(taskId, { lastBytes: downloadedSoFar, lastTime: performance.now() });

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          existingChunks.push(value);
          downloadedSoFar += value.length;

          // Sample speed and calculate progress
          const now = performance.now();
          const sampler = speedSamplers.current.get(taskId);
          let currentSpeed = 0;
          let calculatedEta = 0;

          if (sampler && now - sampler.lastTime >= 300) {
            const bytesDiff = downloadedSoFar - sampler.lastBytes;
            const timeDiffSec = (now - sampler.lastTime) / 1000;
            currentSpeed = Math.round(bytesDiff / timeDiffSec);
            sampler.lastBytes = downloadedSoFar;
            sampler.lastTime = now;

            if (totalBytes > 0 && currentSpeed > 0) {
              const remaining = totalBytes - downloadedSoFar;
              calculatedEta = Math.max(0, Math.round(remaining / currentSpeed));
            }

            const progress = totalBytes > 0 ? Math.min(100, Math.round((downloadedSoFar / totalBytes) * 100)) : 50;

            setTasks((prev) => {
              const item = prev.get(taskId);
              if (!item || item.status !== 'downloading') return prev;
              const next = new Map(prev);
              next.set(taskId, {
                ...item,
                downloadedBytes: downloadedSoFar,
                fileSize: totalBytes,
                progress,
                speed: currentSpeed,
                eta: calculatedEta,
              });
              return next;
            });
          }
        }

        if (downloadedSoFar === 0) {
          throw new Error('Downloaded file payload was 0 bytes. Stream was empty or prematurely severed.');
        }

        // Assemble Blob and verify
        const blob = new Blob(existingChunks as BlobPart[]);
        if (blob.size === 0) {
          throw new Error('Verified media blob was 0 bytes.');
        }

        const blobUrl = URL.createObjectURL(blob);
        const finishedAt = Date.now();
        const durationSec = Math.max(1, Math.round((finishedAt - currentTask.startedAt) / 1000));

        setTasks((prev) => {
          const item = prev.get(taskId);
          if (!item) return prev;
          const next = new Map(prev);
          next.set(taskId, {
            ...item,
            status: 'completed',
            progress: 100,
            downloadedBytes: downloadedSoFar,
            fileSize: totalBytes || downloadedSoFar,
            speed: 0,
            eta: 0,
            completedAt: finishedAt,
            blobUrl,
          });
          return next;
        });

        // Add to persistent history
        const historyItem: DownloadHistoryItem = {
          id: taskId,
          url: currentTask.url,
          filename: currentTask.filename,
          type: currentTask.type,
          fileSize: totalBytes || downloadedSoFar,
          status: 'completed',
          completedAt: new Date().toISOString(),
          savePath: `${settings.downloadDirectory}\\${currentTask.filename}`,
          downloadDurationSec: durationSec,
        };

        setHistory((prev) => [historyItem, ...prev]);

        // Auto trigger download to client filesystem
        saveBlobToDisk(blobUrl, currentTask.filename);

        showToast(
          'Download Completed & Verified',
          `${currentTask.filename} (${(downloadedSoFar / (1024 * 1024)).toFixed(2)} MB) saved to ${settings.downloadDirectory}.`,
          'success'
        );
      } catch (err: any) {
        if (err.name === 'AbortError') {
          // Intentionally paused or cancelled
          return;
        }

        setTasks((prev) => {
          const item = prev.get(taskId);
          if (!item) return prev;
          const next = new Map(prev);
          next.set(taskId, {
            ...item,
            status: 'failed',
            speed: 0,
            eta: 0,
            errorMessage: err.message || 'Stream download interrupted.',
          });
          return next;
        });

        const historyItem: DownloadHistoryItem = {
          id: taskId,
          url: currentTask.url,
          filename: currentTask.filename,
          type: currentTask.type,
          fileSize: downloadedSoFar,
          status: 'failed',
          completedAt: new Date().toISOString(),
          savePath: `${settings.downloadDirectory}\\${currentTask.filename}`,
          downloadDurationSec: 0,
          errorMessage: err.message,
        };

        setHistory((prev) => [historyItem, ...prev]);
        showToast('Download Interrupted', `${currentTask.filename}: ${err.message}`, 'error');
      } finally {
        abortControllers.current.delete(taskId);
        speedSamplers.current.delete(taskId);
      }
    },
    [tasks, settings.downloadDirectory, saveBlobToDisk, showToast]
  );

  // Queue orchestrator: monitors active tasks and dequeues queued ones
  useEffect(() => {
    const list = Array.from(tasks.values());
    const activeCount = list.filter((t) => t.status === 'downloading').length;

    if (activeCount < settings.maxConcurrent) {
      const nextQueued = list.find((t) => t.status === 'queued');
      if (nextQueued) {
        runDownload(nextQueued.id);
      }
    }
  }, [tasks, settings.maxConcurrent, runDownload]);

  const enqueueDownload = useCallback(
    (url: string, filename: string, type: MediaType = 'document', initialSize = 0): string => {
      const id = `task_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const safeFilename = filename.trim().replace(/[\\/:*?"<>|]/g, '_');

      const newTask: DownloadTask = {
        id,
        url,
        filename: safeFilename,
        type,
        fileSize: initialSize,
        downloadedBytes: 0,
        progress: 0,
        speed: 0,
        eta: 0,
        status: 'queued',
        startedAt: Date.now(),
        savePath: `${settings.downloadDirectory}\\${safeFilename}`,
      };

      setTasks((prev) => {
        const next = new Map(prev);
        next.set(id, newTask);
        return next;
      });

      showToast('Download Queued', `Added ${safeFilename} to download queue.`);
      return id;
    },
    [settings.downloadDirectory, showToast]
  );

  const enqueueBatchDownloads = useCallback(
    (items: { url: string; filename: string; type?: MediaType; size?: number }[]) => {
      if (items.length === 0) return;
      items.forEach((item) => {
        enqueueDownload(item.url, item.filename, item.type || 'document', item.size || 0);
      });
      showToast('Batch Added', `Enqueued ${items.length} media files for download.`, 'info');
    },
    [enqueueDownload, showToast]
  );

  const pauseDownload = useCallback((id: string) => {
    const controller = abortControllers.current.get(id);
    if (controller) {
      controller.abort();
    }
    setTasks((prev) => {
      const item = prev.get(id);
      if (!item || item.status !== 'downloading') return prev;
      const next = new Map(prev);
      next.set(id, { ...item, status: 'paused', speed: 0, eta: 0 });
      return next;
    });
  }, []);

  const resumeDownload = useCallback((id: string) => {
    setTasks((prev) => {
      const item = prev.get(id);
      if (!item || item.status !== 'paused') return prev;
      const next = new Map(prev);
      next.set(id, { ...item, status: 'queued' });
      return next;
    });
  }, []);

  const cancelDownload = useCallback((id: string) => {
    const controller = abortControllers.current.get(id);
    if (controller) {
      controller.abort();
    }
    chunkBuffers.current.delete(id);
    speedSamplers.current.delete(id);

    setTasks((prev) => {
      const item = prev.get(id);
      if (!item) return prev;
      const next = new Map(prev);
      next.set(id, { ...item, status: 'cancelled', speed: 0, eta: 0 });
      return next;
    });
  }, []);

  const retryDownload = useCallback((id: string) => {
    chunkBuffers.current.delete(id);
    setTasks((prev) => {
      const item = prev.get(id);
      if (!item) return prev;
      const next = new Map(prev);
      next.set(id, {
        ...item,
        status: 'queued',
        downloadedBytes: 0,
        progress: 0,
        speed: 0,
        eta: 0,
        errorMessage: undefined,
        startedAt: Date.now(),
      });
      return next;
    });
  }, []);

  const clearCompletedDownloads = useCallback(() => {
    setTasks((prev) => {
      const next = new Map();
      prev.forEach((t, k) => {
        if (t.status !== 'completed' && t.status !== 'cancelled') {
          next.set(k, t);
        }
      });
      return next;
    });
  }, []);

  const clearHistory = useCallback(() => {
    setHistory([]);
    showToast('History Cleared', 'Download history log has been cleared.');
  }, [showToast]);

  const deleteHistoryItem = useCallback((id: string) => {
    setHistory((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const updateSettings = useCallback((partial: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  }, []);

  const exportHistory = useCallback(
    (format: 'json' | 'csv') => {
      if (history.length === 0) {
        showToast('Export Notice', 'No history records to export.', 'warning');
        return;
      }
      let content = '';
      let mimeType = 'text/plain';
      let extension = 'txt';

      if (format === 'json') {
        content = JSON.stringify(history, null, 2);
        mimeType = 'application/json';
        extension = 'json';
      } else {
        const headers = ['ID', 'Filename', 'Type', 'Size (Bytes)', 'Status', 'Date', 'URL', 'Save Path'];
        const rows = history.map((h) => [
          `"${h.id}"`,
          `"${h.filename.replace(/"/g, '""')}"`,
          `"${h.type}"`,
          h.fileSize,
          `"${h.status}"`,
          `"${h.completedAt}"`,
          `"${h.url.replace(/"/g, '""')}"`,
          `"${h.savePath.replace(/"/g, '""')}"`,
        ]);
        content = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
        mimeType = 'text/csv';
        extension = 'csv';
      }

      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      saveBlobToDisk(url, `ACP_Download_History_${new Date().toISOString().slice(0, 10)}.${extension}`);
      showToast('Export Successful', `History exported as ${extension.toUpperCase()}.`, 'success');
    },
    [history, saveBlobToDisk, showToast]
  );

  // Batch download bundle to ZIP archive
  const downloadAsZip = useCallback(
    async (items: { url: string; filename: string }[], zipName = 'ACP_Media_Batch.zip') => {
      if (items.length === 0) return;
      showToast('Generating ZIP', `Packaging ${items.length} files into archive...`, 'info');
      try {
        const zip = new JSZip();

        for (let i = 0; i < items.length; i++) {
          const item = items[i];
          try {
            const proxyUrl = `/api/proxy-download?url=${encodeURIComponent(item.url)}&filename=${encodeURIComponent(
              item.filename
            )}`;
            const res = await fetch(proxyUrl);
            if (res.ok) {
              const buffer = await res.arrayBuffer();
              zip.file(item.filename, buffer);
            }
          } catch {
            // continue with remaining files
          }
        }

        const zipBlob = await zip.generateAsync({ type: 'blob' });
        const zipUrl = URL.createObjectURL(zipBlob);
        saveBlobToDisk(zipUrl, zipName);
        showToast('ZIP Download Ready', `Successfully bundled and downloaded ${zipName}.`, 'success');
      } catch (err: any) {
        showToast('ZIP Bundle Failed', err.message || 'Error compiling zip file.', 'error');
      }
    },
    [saveBlobToDisk, showToast]
  );

  // Computed metrics
  const taskList = Array.from(tasks.values());
  const currentSpeedBps = taskList.reduce((acc, t) => acc + (t.status === 'downloading' ? t.speed : 0), 0);
  const completedCount = history.filter((h) => h.status === 'completed').length;
  const failedCount = history.filter((h) => h.status === 'failed').length;
  const totalBytesDownloaded = history.reduce((acc, h) => acc + (h.status === 'completed' ? h.fileSize : 0), 0);

  return (
    <DownloadEngineContext.Provider
      value={{
        activeDownloads: taskList,
        history,
        settings,
        currentPage,
        setCurrentPage,
        toasts,
        removeToast,
        showToast,
        analyzeUrl,
        enqueueDownload,
        enqueueBatchDownloads,
        pauseDownload,
        resumeDownload,
        cancelDownload,
        retryDownload,
        clearCompletedDownloads,
        clearHistory,
        deleteHistoryItem,
        updateSettings,
        exportHistory,
        downloadAsZip,
        saveBlobToDisk,
        systemMetrics: {
          totalBytesDownloaded,
          completedCount,
          failedCount,
          currentSpeedBps,
        },
      }}
    >
      {children}
    </DownloadEngineContext.Provider>
  );
};

export const useDownloadEngine = () => {
  const context = useContext(DownloadEngineContext);
  if (!context) {
    throw new Error('useDownloadEngine must be used within a DownloadEngineProvider');
  }
  return context;
};
