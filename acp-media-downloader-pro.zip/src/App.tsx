/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { DownloadEngineProvider, useDownloadEngine } from './context/DownloadEngineContext';
import { TitleBar } from './components/TitleBar';
import { Sidebar } from './components/Sidebar';
import { NotificationToastContainer } from './components/NotificationToast';

import { Home } from './pages/Home';
import { UniversalDownloader } from './pages/UniversalDownloader';
import { ImageDownloader } from './pages/ImageDownloader';
import { VideoDownloader } from './pages/VideoDownloader';
import { BatchDownloader } from './pages/BatchDownloader';
import { DownloadManagerPage } from './pages/DownloadManagerPage';
import { HistoryPage } from './pages/HistoryPage';
import { SettingsPage } from './pages/SettingsPage';
import { AboutPage } from './pages/AboutPage';

const AppContent: React.FC = () => {
  const { currentPage } = useDownloadEngine();

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#030712] text-slate-100 select-none">
      {/* Windows 10/11 Desktop Title Bar */}
      <TitleBar />

      {/* Main Workspace */}
      <div className="flex flex-1 overflow-hidden">
        {/* Modern Sidebar Navigation */}
        <Sidebar />

        {/* Primary Viewport */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-[#040814]/90 custom-scrollbar">
          <div className="max-w-6xl mx-auto">
            {currentPage === 'home' && <Home />}
            {currentPage === 'universal' && <UniversalDownloader />}
            {currentPage === 'images' && <ImageDownloader />}
            {currentPage === 'videos' && <VideoDownloader />}
            {currentPage === 'batch' && <BatchDownloader />}
            {currentPage === 'manager' && <DownloadManagerPage />}
            {currentPage === 'history' && <HistoryPage />}
            {currentPage === 'settings' && <SettingsPage />}
            {currentPage === 'about' && <AboutPage />}
          </div>
        </main>
      </div>

      {/* Windows Desktop Notifications */}
      <NotificationToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <DownloadEngineProvider>
      <AppContent />
    </DownloadEngineProvider>
  );
}
