import React, { useState } from 'react';
import {
  Image,
  Search,
  DownloadCloud,
  CheckSquare,
  Square,
  Archive,
  Eye,
  X,
  ExternalLink,
  Layers,
  AlertCircle,
  Activity,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';
import { AnalyzedMediaItem } from '../types';

export const ImageDownloader: React.FC = () => {
  const { enqueueDownload, enqueueBatchDownloads, downloadAsZip, showToast, analyzeUrl } = useDownloadEngine();

  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState<AnalyzedMediaItem[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [previewItem, setPreviewItem] = useState<AnalyzedMediaItem | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleScanImages = async () => {
    if (!url.trim()) return;
    setLoading(true);
    setErrorMsg(null);
    setImages([]);
    setSelectedIds(new Set());

    try {
      const data = await analyzeUrl(url.trim());
      const foundImages = (data.items || []).filter((i: AnalyzedMediaItem) => i.type === 'image');
      if (foundImages.length > 0) {
        setImages(foundImages);
        showToast('Images Found', `Extracted ${foundImages.length} images from ${data.platformName}.`, 'success');
      } else if (data.restrictionNotice) {
        setErrorMsg(data.restrictionNotice);
      } else {
        setErrorMsg('No accessible images found at this URL. Make sure the page is publicly accessible.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Network error scanning target page.');
    } finally {
      setLoading(false);
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === images.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(images.map((i) => i.id)));
    }
  };

  const downloadSelected = () => {
    const chosen = images.filter((img) => selectedIds.has(img.id));
    if (chosen.length === 0) return;
    enqueueBatchDownloads(
      chosen.map((c) => ({
        url: c.url,
        filename: c.filename,
        type: 'image',
        size: c.sizeBytes,
      }))
    );
  };

  const zipSelected = () => {
    const chosen = images.filter((img) => selectedIds.has(img.id));
    if (chosen.length === 0) return;
    downloadAsZip(
      chosen.map((c) => ({ url: c.url, filename: c.filename })),
      `ACP_Images_Pack_${Date.now()}.zip`
    );
  };

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="pb-2 border-b border-[#142344]">
        <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
          <Image className="w-5 h-5 text-emerald-400" />
          <span>High-Fidelity Image Downloader</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Supports JPG, PNG, WebP, GIF, SVG, and high-resolution web photo collections with batch ZIP bundling.
        </p>
      </div>

      {/* URL Scan Box */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="url"
            placeholder="Paste image page URL or direct image file link..."
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleScanImages()}
            className="flex-1 bg-[#030712] border border-[#1b2d56] focus:border-emerald-400 rounded-lg px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 outline-none font-mono"
          />
          <button
            onClick={handleScanImages}
            disabled={loading || !url.trim()}
            className="px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-[#040814] font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-emerald-500/20 shrink-0"
          >
            {loading ? <Activity className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>{loading ? 'Scanning Images...' : 'Extract Images'}</span>
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}
      </div>

      {/* Results & Actions Bar */}
      {images.length > 0 && (
        <div className="space-y-4">
          <div className="bg-[#071024] border border-[#142344] rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 font-medium text-slate-300">
              <span>Discovered {images.length} accessible pictures</span>
              <span className="text-slate-600">·</span>
              <span className="text-emerald-400">{selectedIds.size} selected</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={toggleSelectAll}
                className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-[#152a54] text-slate-300 border border-[#182d59] flex items-center gap-1.5"
              >
                {selectedIds.size === images.length ? (
                  <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Square className="w-3.5 h-3.5 text-slate-400" />
                )}
                <span>Select All</span>
              </button>

              {selectedIds.size > 0 && (
                <>
                  <button
                    onClick={downloadSelected}
                    className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-[#040814] font-bold flex items-center gap-1.5 shadow-sm"
                  >
                    <DownloadCloud className="w-3.5 h-3.5" />
                    <span>Download ({selectedIds.size})</span>
                  </button>
                  <button
                    onClick={zipSelected}
                    className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-[#152a54] text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5"
                  >
                    <Archive className="w-3.5 h-3.5" />
                    <span>ZIP Bundle</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Image Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {images.map((item) => {
              const isSelected = selectedIds.has(item.id);
              return (
                <div
                  key={item.id}
                  className={`group relative bg-[#071024] border rounded-xl overflow-hidden flex flex-col justify-between transition-all ${
                    isSelected ? 'border-emerald-400 shadow-md shadow-emerald-400/10' : 'border-[#142344] hover:border-[#1d3361]'
                  }`}
                >
                  <div className="aspect-square bg-[#030712] relative overflow-hidden flex items-center justify-center">
                    <img
                      src={`/api/media-preview?url=${encodeURIComponent(item.url)}`}
                      alt={item.filename}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Checkbox */}
                    <button
                      onClick={() => toggleSelect(item.id)}
                      className="absolute top-2 left-2 p-1 rounded bg-[#071024]/80 backdrop-blur-sm text-slate-200"
                    >
                      {isSelected ? (
                        <CheckSquare className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-400" />
                      )}
                    </button>

                    {/* Quick Preview Eye */}
                    <button
                      onClick={() => setPreviewItem(item)}
                      title="Inspect full image"
                      className="absolute top-2 right-2 p-1 rounded bg-[#071024]/80 backdrop-blur-sm text-slate-300 hover:text-white"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>

                    {/* Format Badge */}
                    <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-[#040814]/90 text-[10px] font-mono text-slate-300 border border-[#1b2c52] uppercase">
                      {item.format}
                    </div>
                  </div>

                  <div className="p-2.5 space-y-1.5">
                    <div className="font-medium text-xs text-slate-200 truncate" title={item.filename}>
                      {item.filename}
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                      <span>{item.resolution || 'Original'}</span>
                      <button
                        onClick={() => enqueueDownload(item.url, item.filename, 'image', item.sizeBytes)}
                        className="text-emerald-400 hover:underline font-sans font-semibold cursor-pointer"
                      >
                        Download
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {previewItem && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#071024] border border-[#1b2f5c] rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-3.5 border-b border-[#142344] flex items-center justify-between">
              <div className="font-semibold text-xs text-slate-200 truncate max-w-md">
                {previewItem.filename}
              </div>
              <button
                onClick={() => setPreviewItem(null)}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 flex-1 overflow-auto flex items-center justify-center bg-[#030712]">
              <img
                src={`/api/media-preview?url=${encodeURIComponent(previewItem.url)}`}
                alt={previewItem.filename}
                referrerPolicy="no-referrer"
                className="max-h-[60vh] max-w-full object-contain rounded-lg"
              />
            </div>
            <div className="p-3.5 border-t border-[#142344] flex items-center justify-between text-xs">
              <span className="font-mono text-slate-400 text-[11px]">{previewItem.format} · {previewItem.resolution || 'Original Resolution'}</span>
              <button
                onClick={() => {
                  enqueueDownload(previewItem.url, previewItem.filename, 'image', previewItem.sizeBytes);
                  setPreviewItem(null);
                }}
                className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-[#040814] font-bold flex items-center gap-2 cursor-pointer shadow-md"
              >
                <DownloadCloud className="w-3.5 h-3.5" />
                <span>Save Image File</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
