import React, { useState } from 'react';
import {
  Globe,
  Search,
  Filter,
  DownloadCloud,
  FileImage,
  FileVideo,
  FileAudio,
  FileText,
  CheckSquare,
  Square,
  Archive,
  ExternalLink,
  AlertCircle,
  Activity,
  Layers,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';
import { AnalyzedMediaItem, MediaType, PlatformAnalysisResult } from '../types';
import { Info } from 'lucide-react';

export const UniversalDownloader: React.FC = () => {
  const { enqueueDownload, enqueueBatchDownloads, downloadAsZip, showToast, analyzeUrl } = useDownloadEngine();

  const [inputUrl, setInputUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [platformResult, setPlatformResult] = useState<PlatformAnalysisResult | null>(null);
  const [items, setItems] = useState<AnalyzedMediaItem[]>([]);
  const [pageTitle, setPageTitle] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<'all' | MediaType>('all');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const handleInspect = async (overrideUrl?: string) => {
    const targetUrl = (overrideUrl || inputUrl).trim();
    if (!targetUrl) return;

    setLoading(true);
    setErrorMsg(null);
    setItems([]);
    setSelectedIds(new Set());
    setPlatformResult(null);

    try {
      const data = await analyzeUrl(targetUrl);
      setPlatformResult(data);
      setPageTitle(data.pageTitle || 'Extracted Resources');

      if (data.items && data.items.length > 0) {
        setItems(data.items);
        showToast('Analysis Complete', `Found ${data.items.length} downloadable media assets on ${data.platformName}.`, 'success');
      } else if (data.restrictionNotice) {
        // Will be rendered in the restriction card
      } else {
        setErrorMsg('No accessible images, videos, audio, or document links detected on this page.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error occurred while contacting destination host.');
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = items.filter((item) => {
    if (selectedFilter === 'all') return true;
    return item.type === selectedFilter;
  });

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredItems.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredItems.map((i) => i.id)));
    }
  };

  const handleDownloadSelected = () => {
    const chosen = items.filter((i) => selectedIds.has(i.id));
    if (chosen.length === 0) return;
    enqueueBatchDownloads(
      chosen.map((c) => ({
        url: c.url,
        filename: c.filename,
        type: c.type,
        size: c.sizeBytes,
      }))
    );
  };

  const handleZipSelected = () => {
    const chosen = items.filter((i) => selectedIds.has(i.id));
    if (chosen.length === 0) return;
    downloadAsZip(
      chosen.map((c) => ({ url: c.url, filename: c.filename })),
      `${pageTitle.slice(0, 20).replace(/\W+/g, '_')}_media_pack.zip`
    );
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="pb-2 border-b border-[#142344]">
        <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
          <Globe className="w-5 h-5 text-[#00E5FF]" />
          <span>Universal Media Downloader</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Inspects any public web URL for authorized media, extracts video streams, images, and direct download links.
        </p>
      </div>

      {/* URL Input Box */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="url"
            placeholder="Enter public web address (e.g. https://domain.org/article or https://example.com/asset.mp4)..."
            value={inputUrl}
            onChange={(e) => setInputUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleInspect()}
            className="flex-1 bg-[#030712] border border-[#1b2d56] focus:border-[#00E5FF] rounded-lg px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 outline-none font-mono"
          />
          <button
            onClick={() => handleInspect()}
            disabled={loading || !inputUrl.trim()}
            className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#00E5FF] to-[#0284c7] hover:opacity-95 disabled:opacity-50 text-[#040814] font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-[#00E5FF]/20 shrink-0"
          >
            {loading ? <Activity className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>{loading ? 'Inspecting Webpage...' : 'Analyze Media'}</span>
          </button>
        </div>

        {/* Demo presets */}
        <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
          <span>Quick presets:</span>
          <button
            onClick={() => {
              const url = 'https://en.wikipedia.org/wiki/Aurora';
              setInputUrl(url);
              handleInspect(url);
            }}
            className="text-[#00E5FF] hover:underline"
          >
            Wikipedia Aurora Article
          </button>
          <span>·</span>
          <button
            onClick={() => {
              const url = 'https://images-assets.nasa.gov/video/NHQ_2019_0716_Apollo%2011%2050th%20Anniversary%20Broadcast/NHQ_2019_0716_Apollo%2011%2050th%20Anniversary%20Broadcast~orig.mp4';
              setInputUrl(url);
              handleInspect(url);
            }}
            className="text-[#00E5FF] hover:underline"
          >
            NASA Direct Video
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <div>
              <div className="font-semibold">Inspection Notice</div>
              <div className="text-[11px] text-rose-200 mt-0.5">{errorMsg}</div>
            </div>
          </div>
        )}

        {platformResult?.restrictionNotice && (
          <div className="p-3.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 font-semibold text-amber-300">
              <Info className="w-4 h-4" />
              <span>{platformResult.platformName} Platform Guidance</span>
            </div>
            <p className="text-[11px] leading-relaxed text-amber-200">{platformResult.restrictionNotice}</p>
            {platformResult.authHelp && (
              <div className="text-[10px] text-amber-300/90 font-mono bg-[#030712]/60 p-2 rounded border border-amber-500/20">
                💡 Creator / Permitted Method: {platformResult.authHelp}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Result Section */}
      {items.length > 0 && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-[#071024] border border-[#142344] rounded-xl p-3 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            {/* Filter Tabs */}
            <div className="flex items-center gap-1 bg-[#040814] p-1 rounded-lg border border-[#111f3d]">
              {(['all', 'video', 'image', 'audio', 'document'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setSelectedFilter(tab)}
                  className={`px-3 py-1.5 rounded-md font-medium capitalize transition-all ${
                    selectedFilter === tab
                      ? 'bg-[#00E5FF] text-[#040814] font-bold shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab === 'all' ? `All (${items.length})` : `${tab}s (${items.filter((i) => i.type === tab).length})`}
                </button>
              ))}
            </div>

            {/* Batch actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={toggleSelectAll}
                className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-[#152a54] text-slate-300 border border-[#182d59] flex items-center gap-1.5"
              >
                {selectedIds.size === filteredItems.length && filteredItems.length > 0 ? (
                  <CheckSquare className="w-3.5 h-3.5 text-[#00E5FF]" />
                ) : (
                  <Square className="w-3.5 h-3.5 text-slate-400" />
                )}
                <span>Select All ({filteredItems.length})</span>
              </button>

              {selectedIds.size > 0 && (
                <>
                  <button
                    onClick={handleDownloadSelected}
                    className="px-3 py-1.5 rounded-lg bg-[#0284c7] hover:bg-[#0369a1] text-white font-medium flex items-center gap-1.5 shadow-sm"
                  >
                    <DownloadCloud className="w-3.5 h-3.5" />
                    <span>Download Selected ({selectedIds.size})</span>
                  </button>
                  <button
                    onClick={handleZipSelected}
                    className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-[#152a54] text-[#00E5FF] border border-[#00E5FF]/30 flex items-center gap-1.5"
                  >
                    <Archive className="w-3.5 h-3.5" />
                    <span>Save as ZIP</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {filteredItems.map((item) => {
              const isSelected = selectedIds.has(item.id);
              let icon = <FileText className="w-5 h-5 text-slate-400" />;
              if (item.type === 'video') icon = <FileVideo className="w-5 h-5 text-[#00E5FF]" />;
              else if (item.type === 'image') icon = <FileImage className="w-5 h-5 text-emerald-400" />;
              else if (item.type === 'audio') icon = <FileAudio className="w-5 h-5 text-amber-400" />;

              return (
                <div
                  key={item.id}
                  className={`bg-[#071024] border rounded-xl overflow-hidden flex flex-col justify-between transition-all ${
                    isSelected ? 'border-[#00E5FF] shadow-md shadow-[#00E5FF]/10' : 'border-[#142344] hover:border-[#1d3361]'
                  }`}
                >
                  {/* Media Visual Area */}
                  <div className="h-36 bg-[#030712] relative flex items-center justify-center overflow-hidden border-b border-[#121f3d]">
                    {item.type === 'image' ? (
                      <img
                        src={`/api/media-preview?url=${encodeURIComponent(item.url)}`}
                        alt={item.filename}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          // Fallback container
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : item.type === 'video' ? (
                      <div className="text-center p-3">
                        <FileVideo className="w-10 h-10 text-[#00E5FF] mx-auto opacity-70" />
                        <span className="text-[10px] text-slate-400 font-mono mt-1 block">
                          {item.resolution || 'Direct Video Stream'}
                        </span>
                      </div>
                    ) : (
                      <div className="text-center p-3">
                        {icon}
                        <span className="text-[10px] text-slate-400 font-mono mt-1 block uppercase">
                          {item.format} Media
                        </span>
                      </div>
                    )}

                    {/* Selection Checkbox */}
                    <button
                      onClick={() => toggleSelect(item.id)}
                      className="absolute top-2 left-2 p-1 rounded bg-[#071024]/80 backdrop-blur-sm text-slate-200 hover:text-white"
                    >
                      {isSelected ? (
                        <CheckSquare className="w-4 h-4 text-[#00E5FF]" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-400" />
                      )}
                    </button>

                    {/* Format Badge */}
                    <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-[#040814]/90 text-[10px] font-mono text-slate-300 border border-[#1b2c52] uppercase">
                      {item.format}
                    </div>
                  </div>

                  {/* Media Information */}
                  <div className="p-3 flex-1 flex flex-col justify-between space-y-2.5">
                    <div>
                      <div className="font-semibold text-xs text-slate-100 truncate" title={item.filename}>
                        {item.filename}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                        <span className="truncate max-w-[150px]">{item.sourceContext || 'Web Resource'}</span>
                        <span className="font-mono text-slate-400 text-[10px]">{item.resolution || 'Standard'}</span>
                      </div>
                    </div>

                    {/* Action Button */}
                    <div className="pt-2 border-t border-[#101b36] flex items-center gap-2">
                      <button
                        onClick={() => enqueueDownload(item.url, item.filename, item.type, item.sizeBytes)}
                        className="flex-1 py-1.5 px-3 rounded-lg bg-[#0e1d3b] hover:bg-[#00E5FF] hover:text-[#040814] text-[#00E5FF] border border-[#1b3469] hover:border-[#00E5FF] font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <DownloadCloud className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </button>
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noreferrer noopener"
                        title="Open direct URL in browser"
                        className="p-1.5 rounded-lg bg-[#0a1429] hover:bg-[#122247] text-slate-400 hover:text-slate-200 border border-[#15264d]"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
