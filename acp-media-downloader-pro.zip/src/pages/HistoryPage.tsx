import React, { useState } from 'react';
import {
  History as HistoryIcon,
  Search,
  Download,
  Trash2,
  FileSpreadsheet,
  FileCode,
  RotateCcw,
  ExternalLink,
  CheckCircle2,
  XCircle,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';

export const HistoryPage: React.FC = () => {
  const { history, clearHistory, deleteHistoryItem, exportHistory, enqueueDownload, showToast } =
    useDownloadEngine();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'failed'>('all');

  const filteredHistory = history.filter((item) => {
    const matchesSearch =
      item.filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.url.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.savePath.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;
    if (statusFilter !== 'all' && item.status !== statusFilter) return false;
    return true;
  });

  const totalSizeMb = (history.reduce((acc, h) => acc + h.fileSize, 0) / (1024 * 1024)).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#142344]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
            <HistoryIcon className="w-5 h-5 text-[#00E5FF]" />
            <span>Download History Log</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Archived records of all completed, aborted, and failed media extractions with SQLite persistent sync.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => exportHistory('csv')}
            disabled={history.length === 0}
            className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-[#162e5c] text-slate-300 border border-[#16274e] text-xs font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            title="Export records to CSV spreadsheet"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => exportHistory('json')}
            disabled={history.length === 0}
            className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-[#162e5c] text-slate-300 border border-[#16274e] text-xs font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            title="Export records to JSON file"
          >
            <FileCode className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span>Export JSON</span>
          </button>
          <button
            onClick={clearHistory}
            disabled={history.length === 0}
            className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-rose-950/40 text-slate-300 hover:text-rose-400 border border-[#16274e] text-xs font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search records by filename, path, or URL..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#030712] border border-[#1b2d56] focus:border-[#00E5FF] rounded-lg pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 outline-none"
          />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex items-center gap-1 bg-[#040814] p-1 rounded-lg border border-[#111f3d]">
            {(['all', 'completed', 'failed'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setStatusFilter(filter)}
                className={`px-3 py-1 rounded capitalize font-medium transition-all ${
                  statusFilter === filter
                    ? 'bg-[#00E5FF] text-[#040814] font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          <span className="text-[11px] text-slate-400 font-mono">
            {filteredHistory.length} items ({totalSizeMb} MB total)
          </span>
        </div>
      </div>

      {/* History Table */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl overflow-hidden shadow-lg">
        {filteredHistory.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
            <HistoryIcon className="w-8 h-8 text-slate-600" />
            <span>No records found in download history.</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#040814] text-slate-400 border-b border-[#121f3d] font-semibold text-[11px]">
                <tr>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Filename</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">File Size</th>
                  <th className="py-2.5 px-3">Target Path</th>
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0f1d3b]">
                {filteredHistory.map((item) => {
                  const sizeMb = (item.fileSize / (1024 * 1024)).toFixed(2);
                  const isSuccess = item.status === 'completed';

                  return (
                    <tr key={item.id} className="hover:bg-[#09152e] transition-colors">
                      <td className="py-2.5 px-3">
                        {isSuccess ? (
                          <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Done</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 text-rose-400 font-medium">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Failed</span>
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-200 max-w-xs truncate" title={item.filename}>
                        {item.filename}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#030712] text-[#00E5FF] border border-[#16274e] uppercase">
                          {item.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-slate-300 tabular-nums">
                        {sizeMb} MB
                      </td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-400 truncate max-w-[200px]" title={item.savePath}>
                        {item.savePath}
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                        {new Date(item.completedAt).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => enqueueDownload(item.url, item.filename, item.type)}
                            className="p-1 rounded text-slate-400 hover:text-[#00E5FF] cursor-pointer"
                            title="Re-download item"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteHistoryItem(item.id)}
                            className="p-1 rounded text-slate-400 hover:text-rose-400 cursor-pointer"
                            title="Delete record from history"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
