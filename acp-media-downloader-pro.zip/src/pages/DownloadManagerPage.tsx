import React, { useState } from 'react';
import {
  ArrowDownToLine,
  Pause,
  Play,
  RotateCcw,
  XCircle,
  FolderOpen,
  CheckCircle2,
  Trash2,
  AlertCircle,
  ExternalLink,
  Activity,
  HardDrive,
  FileCheck,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';
import { DownloadStatus } from '../types';

export const DownloadManagerPage: React.FC = () => {
  const {
    activeDownloads,
    pauseDownload,
    resumeDownload,
    cancelDownload,
    retryDownload,
    clearCompletedDownloads,
    saveBlobToDisk,
    settings,
    systemMetrics,
  } = useDownloadEngine();

  const [activeTab, setActiveTab] = useState<'all' | 'active' | 'completed' | 'failed'>('all');

  const filteredTasks = activeDownloads.filter((task) => {
    if (activeTab === 'active') return task.status === 'downloading' || task.status === 'queued' || task.status === 'paused';
    if (activeTab === 'completed') return task.status === 'completed';
    if (activeTab === 'failed') return task.status === 'failed' || task.status === 'cancelled';
    return true;
  });

  const speedMb = (systemMetrics.currentSpeedBps / (1024 * 1024)).toFixed(2);

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-[#142344]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
            <ArrowDownToLine className="w-5 h-5 text-[#00E5FF]" />
            <span>Download Task Manager</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time stream telemetry, pause/resume state control, and storage verification.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={clearCompletedDownloads}
            className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-[#162e5c] text-slate-300 border border-[#16274e] text-xs font-medium flex items-center gap-1.5 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Finished</span>
          </button>
        </div>
      </div>

      {/* Top Telemetry Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-[#071024] border border-[#142344] p-3 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400">Total Throughput</div>
            <div className="text-lg font-bold font-mono text-slate-100 mt-0.5">{speedMb} MB/s</div>
          </div>
          <Activity className="w-5 h-5 text-[#00E5FF]" />
        </div>

        <div className="bg-[#071024] border border-[#142344] p-3 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400">Active Queue</div>
            <div className="text-lg font-bold font-mono text-slate-100 mt-0.5">
              {activeDownloads.filter((t) => t.status === 'downloading').length} Downloading ·{' '}
              {activeDownloads.filter((t) => t.status === 'queued').length} Queued
            </div>
          </div>
          <HardDrive className="w-5 h-5 text-sky-400" />
        </div>

        <div className="bg-[#071024] border border-[#142344] p-3 rounded-xl flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400">Target Folder</div>
            <div className="text-xs font-mono text-slate-300 truncate max-w-[180px] mt-0.5" title={settings.downloadDirectory}>
              {settings.downloadDirectory}
            </div>
          </div>
          <FolderOpen className="w-5 h-5 text-amber-400" />
        </div>
      </div>

      {/* Tab Filter Bar */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl p-2.5 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1 bg-[#040814] p-1 rounded-lg border border-[#111f3d]">
          {(['all', 'active', 'completed', 'failed'] as const).map((tab) => {
            const count = activeDownloads.filter((t) => {
              if (tab === 'active') return t.status === 'downloading' || t.status === 'queued' || t.status === 'paused';
              if (tab === 'completed') return t.status === 'completed';
              if (tab === 'failed') return t.status === 'failed' || t.status === 'cancelled';
              return true;
            }).length;

            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1.5 rounded-md font-medium capitalize transition-all ${
                  activeTab === tab
                    ? 'bg-[#00E5FF] text-[#040814] font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab} ({count})
              </button>
            );
          })}
        </div>

        <span className="text-[11px] text-slate-500 font-mono hidden sm:inline">
          Max Concurrency: {settings.maxConcurrent}
        </span>
      </div>

      {/* Tasks List */}
      <div className="space-y-3">
        {filteredTasks.length === 0 ? (
          <div className="bg-[#071024] border border-[#142344] rounded-xl p-12 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-2">
            <ArrowDownToLine className="w-8 h-8 text-slate-600" />
            <span>No tasks found in the &quot;{activeTab}&quot; category.</span>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const speedKbs = (task.speed / 1024).toFixed(0);
            const downloadedMb = (task.downloadedBytes / (1024 * 1024)).toFixed(2);
            const totalMb = task.fileSize > 0 ? (task.fileSize / (1024 * 1024)).toFixed(2) : '?';

            return (
              <div
                key={task.id}
                className="bg-[#071024] border border-[#142344] hover:border-[#1d3361] rounded-xl p-4 transition-all space-y-3 text-xs"
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 truncate">
                    <span className="font-semibold text-slate-100 truncate text-sm">{task.filename}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#030712] text-[#00E5FF] border border-[#16274e] uppercase shrink-0">
                      {task.type}
                    </span>
                    <span className="text-[11px] font-mono text-slate-400 truncate hidden md:inline max-w-xs">
                      {task.url}
                    </span>
                  </div>

                  {/* Action Controls */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {task.status === 'downloading' && (
                      <button
                        onClick={() => pauseDownload(task.id)}
                        className="px-2.5 py-1 rounded bg-[#0e1d3b] hover:bg-[#162e5c] text-slate-300 flex items-center gap-1 cursor-pointer"
                        title="Pause Stream"
                      >
                        <Pause className="w-3.5 h-3.5" />
                        <span>Pause</span>
                      </button>
                    )}

                    {task.status === 'paused' && (
                      <button
                        onClick={() => resumeDownload(task.id)}
                        className="px-2.5 py-1 rounded bg-[#0e1d3b] hover:bg-[#162e5c] text-[#00E5FF] flex items-center gap-1 cursor-pointer"
                        title="Resume Stream"
                      >
                        <Play className="w-3.5 h-3.5" />
                        <span>Resume</span>
                      </button>
                    )}

                    {task.status === 'failed' && (
                      <button
                        onClick={() => retryDownload(task.id)}
                        className="px-2.5 py-1 rounded bg-[#0e1d3b] hover:bg-[#162e5c] text-amber-400 flex items-center gap-1 cursor-pointer"
                        title="Retry Download"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Retry</span>
                      </button>
                    )}

                    {task.blobUrl && task.status === 'completed' && (
                      <button
                        onClick={() => saveBlobToDisk(task.blobUrl!, task.filename)}
                        className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500 hover:text-[#040814] flex items-center gap-1 transition-colors cursor-pointer"
                        title="Save again to computer"
                      >
                        <FileCheck className="w-3.5 h-3.5" />
                        <span>Save File</span>
                      </button>
                    )}

                    {(task.status === 'downloading' || task.status === 'queued' || task.status === 'paused') && (
                      <button
                        onClick={() => cancelDownload(task.id)}
                        className="p-1 rounded bg-[#0e1d3b] hover:bg-rose-900/40 text-slate-400 hover:text-rose-400 cursor-pointer"
                        title="Cancel Task"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Progress Track */}
                <div className="w-full h-2 rounded-full bg-[#030712] overflow-hidden border border-[#111f3d]">
                  <div
                    className={`h-full transition-all duration-300 ${
                      task.status === 'completed'
                        ? 'bg-emerald-400'
                        : task.status === 'failed'
                        ? 'bg-rose-500'
                        : task.status === 'paused'
                        ? 'bg-amber-400'
                        : 'bg-gradient-to-r from-[#0284c7] to-[#00E5FF]'
                    }`}
                    style={{ width: `${task.progress}%` }}
                  />
                </div>

                {/* Status & Stats Footer */}
                <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 font-mono tabular-nums pt-1">
                  <div>
                    {downloadedMb} MB / {totalMb} MB ({task.progress}%)
                  </div>

                  <div className="flex items-center gap-4">
                    {task.status === 'downloading' && (
                      <>
                        <span>Rate: {speedKbs} KB/s</span>
                        <span>ETA: {task.eta}s</span>
                      </>
                    )}
                    <span
                      className={`font-semibold uppercase tracking-wider ${
                        task.status === 'downloading'
                          ? 'text-[#00E5FF]'
                          : task.status === 'completed'
                          ? 'text-emerald-400'
                          : task.status === 'failed'
                          ? 'text-rose-400'
                          : task.status === 'paused'
                          ? 'text-amber-400'
                          : 'text-slate-400'
                      }`}
                    >
                      {task.status}
                    </span>
                  </div>
                </div>

                {task.errorMessage && (
                  <div className="p-2 rounded bg-rose-500/10 border border-rose-500/20 text-rose-300 text-[11px] flex items-center gap-2">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0 text-rose-400" />
                    <span>{task.errorMessage}</span>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
