import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  HardDrive,
  Sliders,
  Bell,
  Palette,
  Shield,
  RotateCcw,
  Save,
  CheckCircle2,
  FolderOpen,
  Database,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';

export const SettingsPage: React.FC = () => {
  const { settings, updateSettings, showToast, history } = useDownloadEngine();

  const [dir, setDir] = useState(settings.downloadDirectory);
  const [concurrency, setConcurrency] = useState(settings.maxConcurrent);
  const [notifications, setNotifications] = useState(settings.notifications);
  const [autoOpen, setAutoOpen] = useState(settings.autoOpenFolder);
  const [preventDupes, setPreventDupes] = useState(settings.preventDuplicates);
  const [userAgent, setUserAgent] = useState(settings.userAgent);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = () => {
    updateSettings({
      downloadDirectory: dir.trim() || 'C:\\Users\\Default\\Downloads\\ACP Media',
      maxConcurrent: concurrency,
      notifications,
      autoOpenFolder: autoOpen,
      preventDuplicates: preventDupes,
      userAgent,
    });
    setIsSaved(true);
    showToast('Settings Saved', 'Preferences have been persisted to SQLite storage.', 'success');
    setTimeout(() => setIsSaved(false), 2500);
  };

  const handlePickDirectoryPrompt = () => {
    const defaultPaths = [
      'C:\\Users\\Default\\Downloads\\ACP Media',
      'D:\\Media\\ACP Downloads',
      'C:\\Users\\Administrator\\Videos\\ACP Pro',
    ];
    const picked = window.prompt(
      'Enter preferred Windows local storage folder path:',
      dir || defaultPaths[0]
    );
    if (picked) {
      setDir(picked);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex items-center justify-between pb-2 border-b border-[#142344]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-[#00E5FF]" />
            <span>Preferences & Settings</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure Windows storage locations, concurrency throttling, and system network profiles.
          </p>
        </div>

        <button
          onClick={handleSave}
          className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#00E5FF] to-[#0284c7] hover:opacity-95 text-[#040814] font-bold text-xs flex items-center gap-2 cursor-pointer shadow-md shadow-[#00E5FF]/20"
        >
          {isSaved ? <CheckCircle2 className="w-4 h-4 text-emerald-950" /> : <Save className="w-4 h-4" />}
          <span>{isSaved ? 'Preferences Applied' : 'Save Changes'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Section 1: Storage Path */}
        <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 space-y-4">
          <div className="flex items-center gap-2 text-slate-200 font-semibold text-xs border-b border-[#121f3d] pb-2">
            <HardDrive className="w-4 h-4 text-[#00E5FF]" />
            <span>Windows Destination Directory</span>
          </div>

          <div className="space-y-2">
            <label className="text-[11px] text-slate-400">Default Download Folder (Local Windows Path):</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={dir}
                onChange={(e) => setDir(e.target.value)}
                className="flex-1 bg-[#030712] border border-[#1b2d56] focus:border-[#00E5FF] rounded-lg px-3 py-2 text-xs text-slate-100 font-mono outline-none"
              />
              <button
                onClick={handlePickDirectoryPrompt}
                className="px-3 py-2 rounded-lg bg-[#0e1d3b] hover:bg-[#162e5c] text-slate-200 border border-[#16274e] text-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>Browse</span>
              </button>
            </div>
            <p className="text-[10px] text-slate-500">
              Downloaded assets are automatically stored and referenced under this Windows file hierarchy.
            </p>
          </div>

          <div className="pt-2">
            <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
              <span>Automatically trigger browser file download</span>
              <input
                type="checkbox"
                checked={autoOpen}
                onChange={(e) => setAutoOpen(e.target.checked)}
                className="w-4 h-4 accent-[#00E5FF] cursor-pointer"
              />
            </label>
          </div>
        </div>

        {/* Section 2: Concurrency & Engine */}
        <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 space-y-4">
          <div className="flex items-center gap-2 text-slate-200 font-semibold text-xs border-b border-[#121f3d] pb-2">
            <Sliders className="w-4 h-4 text-[#00E5FF]" />
            <span>Transfer Engine & Concurrency</span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Max Concurrent Downloads:</span>
              <span className="font-mono font-bold text-[#00E5FF]">{concurrency} streams</span>
            </div>
            <input
              type="range"
              min={1}
              max={5}
              value={concurrency}
              onChange={(e) => setConcurrency(parseInt(e.target.value, 10))}
              className="w-full accent-[#00E5FF] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>1 (Sequential)</span>
              <span>3 (Recommended)</span>
              <span>5 (Maximum)</span>
            </div>
          </div>

          <div className="pt-2 space-y-2">
            <label className="text-[11px] text-slate-400">Network Client Profile (User-Agent):</label>
            <select
              value={userAgent}
              onChange={(e) => setUserAgent(e.target.value)}
              className="w-full bg-[#030712] border border-[#1b2d56] focus:border-[#00E5FF] rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
            >
              <option value="Chrome 128 (Windows 11)">Chrome 128 on Windows 11 (Recommended)</option>
              <option value="Edge 128 (Windows 11)">Microsoft Edge 128 (Windows 11)</option>
              <option value="Firefox 130 (Windows 10/11)">Mozilla Firefox 130</option>
              <option value="ACP Custom Engine 1.0">ACP Media Downloader Native Client</option>
            </select>
          </div>
        </div>

        {/* Section 3: Notifications & System */}
        <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 space-y-4">
          <div className="flex items-center gap-2 text-slate-200 font-semibold text-xs border-b border-[#121f3d] pb-2">
            <Bell className="w-4 h-4 text-[#00E5FF]" />
            <span>Windows Desktop Alerts</span>
          </div>

          <div className="space-y-3">
            <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
              <span>Enable task completion notifications</span>
              <input
                type="checkbox"
                checked={notifications}
                onChange={(e) => setNotifications(e.target.checked)}
                className="w-4 h-4 accent-[#00E5FF] cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
              <span>Prevent duplicate downloads of active URLs</span>
              <input
                type="checkbox"
                checked={preventDupes}
                onChange={(e) => setPreventDupes(e.target.checked)}
                className="w-4 h-4 accent-[#00E5FF] cursor-pointer"
              />
            </label>
          </div>
        </div>

        {/* Section 4: SQLite Database & Cache Info */}
        <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 space-y-4">
          <div className="flex items-center gap-2 text-slate-200 font-semibold text-xs border-b border-[#121f3d] pb-2">
            <Database className="w-4 h-4 text-[#00E5FF]" />
            <span>Storage Engine & Database Cache</span>
          </div>

          <div className="text-xs space-y-2 text-slate-300">
            <div className="flex justify-between py-1 border-b border-[#121f3d] text-[11px]">
              <span className="text-slate-400">Database Driver:</span>
              <span className="font-mono text-emerald-400 font-medium">SQLite WAL Engine / IndexedDB</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#121f3d] text-[11px]">
              <span className="text-slate-400">Logged Records:</span>
              <span className="font-mono text-slate-100">{history.length} operations</span>
            </div>
            <div className="flex justify-between py-1 text-[11px]">
              <span className="text-slate-400">Encryption & Security:</span>
              <span className="font-mono text-[#00E5FF]">SSRF Hardened</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
