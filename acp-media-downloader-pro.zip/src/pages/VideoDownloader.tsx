import React, { useState } from 'react';
import {
  Video,
  Search,
  DownloadCloud,
  Play,
  Pause,
  ShieldAlert,
  AlertCircle,
  Activity,
  CheckCircle2,
  ExternalLink,
  Info,
  HelpCircle,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';
import { AnalyzedMediaItem, PlatformAnalysisResult, PlatformType } from '../types';

export const VideoDownloader: React.FC = () => {
  const { enqueueDownload, showToast, analyzeUrl } = useDownloadEngine();

  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<PlatformAnalysisResult | null>(null);
  const [videos, setVideos] = useState<AnalyzedMediaItem[]>([]);
  const [activePreview, setActivePreview] = useState<AnalyzedMediaItem | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [platformFilter, setPlatformFilter] = useState<'all' | PlatformType>('all');

  const handleScanVideos = async (overrideUrl?: string) => {
    const target = (overrideUrl || url).trim();
    if (!target) return;

    setLoading(true);
    setErrorMsg(null);
    setVideos([]);
    setActivePreview(null);
    setAnalysisResult(null);

    // DRM protection check
    if (
      target.includes('netflix.com') ||
      target.includes('spotify.com') ||
      target.includes('hulu.com') ||
      target.includes('disneyplus.com')
    ) {
      setErrorMsg(
        'ACP Media Downloader Pro strictly adheres to digital copyright laws and DRM protections. Subscription streaming platforms encrypted with Widevine/PlayReady DRM are protected and cannot be downloaded.'
      );
      setLoading(false);
      return;
    }

    try {
      const data = await analyzeUrl(target);
      setAnalysisResult(data);

      const foundVideos = (data.items || []).filter((i: AnalyzedMediaItem) => i.type === 'video');
      const allFound = data.items || [];

      if (foundVideos.length > 0) {
        setVideos(foundVideos);
        setActivePreview(foundVideos[0]);
        showToast('Video Stream Detected', `Found ${foundVideos.length} accessible video stream(s).`, 'success');
      } else if (allFound.length > 0) {
        setVideos(allFound);
        setActivePreview(allFound[0]);
        showToast('Authorized Media Found', `Retrieved ${allFound.length} verified media asset(s).`, 'info');
      } else if (data.restrictionNotice) {
        // Platform explanation available in data.restrictionNotice
      } else {
        setErrorMsg('No accessible HTML5 video streams (MP4/WebM) or direct links were identified at this address.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error occurred while connecting to video host.');
    } finally {
      setLoading(false);
    }
  };

  const samplePresets = [
    {
      name: 'Facebook Public Video (Verified Stream)',
      url: 'https://www.facebook.com/watch/?v=10153231379946729',
      platform: 'facebook' as const,
    },
    {
      name: 'Direct MP4: NASA Apollo 11 Broadcast',
      url: 'https://images-assets.nasa.gov/video/NHQ_2019_0716_Apollo%2011%2050th%20Anniversary%20Broadcast/NHQ_2019_0716_Apollo%2011%2050th%20Anniversary%20Broadcast~orig.mp4',
      platform: 'direct' as const,
    },
    {
      name: 'YouTube Video Check',
      url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
      platform: 'youtube' as const,
    },
    {
      name: 'Instagram Reel Check',
      url: 'https://www.instagram.com/reel/C_sample_check',
      platform: 'instagram' as const,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="pb-2 border-b border-[#142344]">
        <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
          <Video className="w-5 h-5 text-[#00E5FF]" />
          <span>Universal Video Downloader</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Detects available MP4, WebM, and high-definition video streams for Facebook, YouTube, TikTok, Instagram, and direct media URLs.
        </p>
      </div>

      {/* Input Box */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            placeholder="Paste video stream link (YouTube, TikTok, Facebook, Instagram, or direct .mp4)..."
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleScanVideos()}
            className="flex-1 bg-[#030712] border border-[#1b2d56] focus:border-[#00E5FF] rounded-lg px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 outline-none font-mono"
          />
          <button
            onClick={() => handleScanVideos()}
            disabled={loading || !url.trim()}
            className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#00E5FF] to-[#0284c7] hover:opacity-95 disabled:opacity-50 text-[#040814] font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-[#00E5FF]/20 shrink-0"
          >
            {loading ? <Activity className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>{loading ? 'Inspecting Stream...' : 'Analyze Video'}</span>
          </button>
        </div>

        {/* Quick test presets */}
        <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400 pt-1">
          <span>Supported Platforms:</span>
          {samplePresets.map((s, idx) => (
            <button
              key={idx}
              onClick={() => {
                setUrl(s.url);
                handleScanVideos(s.url);
              }}
              className="px-2 py-0.5 rounded bg-[#0b1836] border border-[#173066] text-[#00E5FF] hover:underline cursor-pointer"
            >
              {s.name}
            </button>
          ))}
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <div>
              <div className="font-semibold">Inspection Error</div>
              <div className="text-[11px] text-rose-200 mt-0.5 leading-relaxed">{errorMsg}</div>
            </div>
          </div>
        )}
      </div>

      {/* Platform Guidance & Policy Card */}
      {analysisResult?.restrictionNotice && (
        <div className="p-4 rounded-xl bg-[#0a1633] border border-[#1b3b78] text-xs text-slate-200 space-y-2">
          <div className="flex items-center gap-2 font-bold text-[#00E5FF]">
            <Info className="w-4 h-4" />
            <span>{analysisResult.platformName} Download Policy & Permissions</span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">{analysisResult.restrictionNotice}</p>
          {analysisResult.authHelp && (
            <div className="p-2.5 rounded-lg bg-[#040814] border border-[#14264d] text-[11px] text-amber-300 font-mono">
              💡 Creator / Authorized Method: {analysisResult.authHelp}
            </div>
          )}
        </div>
      )}

      {/* Video Content & In-App Player */}
      {videos.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Main In-App Player Preview */}
          <div className="lg:col-span-2 bg-[#071024] border border-[#142344] rounded-xl overflow-hidden flex flex-col justify-between">
            <div className="p-3 border-b border-[#142344] flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200 truncate max-w-sm">
                {activePreview?.filename || 'Video Preview'}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#030712] text-[#00E5FF] border border-[#16274e]">
                {activePreview?.resolution || 'HD Stream'}
              </span>
            </div>

            <div className="bg-black aspect-video flex items-center justify-center relative">
              {activePreview && activePreview.type === 'video' ? (
                <video
                  key={activePreview.url}
                  controls
                  className="w-full h-full object-contain"
                  src={`/api/proxy-download?url=${encodeURIComponent(activePreview.url)}&filename=${encodeURIComponent(
                    activePreview.filename
                  )}`}
                >
                  Your browser does not support HTML5 video preview.
                </video>
              ) : activePreview && activePreview.type === 'image' ? (
                <img
                  src={`/api/media-preview?url=${encodeURIComponent(activePreview.url)}`}
                  alt={activePreview.filename}
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="text-slate-500 text-xs">Media preview container</div>
              )}
            </div>

            <div className="p-4 bg-[#050B18] border-t border-[#142344] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
              <div className="text-slate-400 text-[11px]">
                Format: <span className="text-slate-200 font-mono font-medium">{activePreview?.format || 'MP4'}</span> ·
                Platform: <span className="text-slate-200 font-medium">{analysisResult?.platformName || 'Direct'}</span>
              </div>
              <button
                onClick={() => {
                  if (activePreview) {
                    enqueueDownload(activePreview.url, activePreview.filename, activePreview.type, activePreview.sizeBytes);
                  }
                }}
                className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#00E5FF] to-[#0284c7] hover:opacity-95 text-[#040814] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#00E5FF]/20"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>Download Media File</span>
              </button>
            </div>
          </div>

          {/* Available Streams List */}
          <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 flex flex-col justify-between space-y-3">
            <div>
              <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-2">
                Available Media Streams ({videos.length})
              </h3>
              <p className="text-[11px] text-slate-400 mb-3">
                Select an audio/video stream or master artwork below to preview or save to your local Windows drive.
              </p>

              <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
                {videos.map((vid) => {
                  const isActive = activePreview?.id === vid.id;
                  return (
                    <div
                      key={vid.id}
                      onClick={() => setActivePreview(vid)}
                      className={`p-2.5 rounded-lg border cursor-pointer text-xs transition-all ${
                        isActive
                          ? 'bg-[#0d1e3d] border-[#00E5FF] text-[#00E5FF]'
                          : 'bg-[#040814] border-[#132242] text-slate-300 hover:border-[#1d3669]'
                      }`}
                    >
                      <div className="font-semibold truncate">{vid.filename}</div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1 font-mono">
                        <span>{vid.resolution || 'Standard'}</span>
                        <span className="uppercase">{vid.format}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Legal Notice */}
            <div className="p-3 rounded-lg bg-[#040814] border border-[#12213d] text-[10px] text-slate-500 flex items-start gap-2">
              <ShieldAlert className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
              <span>
                Authorized downloads only. ACP Media Downloader Pro complies with platform security policies, copyright, and DMCA regulations.
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
