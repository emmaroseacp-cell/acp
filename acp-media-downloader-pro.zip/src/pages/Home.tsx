import React, { useState } from 'react';
import {
  DownloadCloud,
  ArrowRight,
  Activity,
  HardDrive,
  CheckCircle2,
  Clock,
  Sparkles,
  ExternalLink,
  Pause,
  Play,
  XCircle,
  FileText,
  AlertCircle,
  Zap,
  ShieldCheck,
  Info,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';
import { AnalyzedMediaItem, PlatformAnalysisResult } from '../types';

export const Home: React.FC = () => {
  const {
    activeDownloads,
    history,
    systemMetrics,
    enqueueDownload,
    pauseDownload,
    resumeDownload,
    cancelDownload,
    setCurrentPage,
    showToast,
    analyzeUrl,
  } = useDownloadEngine();

  const [inputUrl, setInputUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<PlatformAnalysisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Five designated test presets as required:
  // 1. Direct MP4 (NASA HD)
  // 2. Direct JPG (Wikimedia Earth)
  // 3. Platform Authorized Media (YouTube)
  // 4. Invalid URL (for testing error handling)
  // 5. Restricted Platform Media (for testing privacy notice)
  const testScenarios = [
    {
      label: '1. Direct Public MP4 Stream',
      url: 'https://images-assets.nasa.gov/video/NHQ_2019_0716_Apollo%2011%2050th%20Anniversary%20Broadcast/NHQ_2019_0716_Apollo%2011%2050th%20Anniversary%20Broadcast~orig.mp4',
      badge: 'Direct MP4',
    },
    {
      label: '2. Public Facebook Video Stream',
      url: 'https://www.facebook.com/watch/?v=10153231379946729',
      badge: 'Public Facebook',
    },
    {
      label: '3. Direct High-Res Image (JPG)',
      url: 'https://upload.wikimedia.org/wikipedia/commons/9/97/The_Earth_seen_from_Apollo_17.jpg',
      badge: 'Direct JPG',
    },
    {
      label: '4. YouTube Platform Video',
      url: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
      badge: 'YouTube',
    },
    {
      label: '5. Inaccessible / Restricted Video',
      url: 'https://www.facebook.com/watch/?v=private_group_sample_video_test',
      badge: 'Restricted Post',
    },
    {
      label: '6. Invalid URL Error Check',
      url: 'invalid://not-a-valid-domain',
      badge: 'Invalid URL',
    },
  ];

  const handleAnalyzeOrDownload = async (overrideUrl?: string) => {
    const target = (overrideUrl || inputUrl).trim();
    if (!target) return;

    setIsAnalyzing(true);
    setErrorMsg(null);
    setAnalysisResult(null);

    try {
      const data = await analyzeUrl(target);
      setAnalysisResult(data);

      if (data.isDirectMedia && data.items.length > 0) {
        // Direct media links can start immediately!
        const primary = data.items[0];
        enqueueDownload(primary.url, primary.filename, primary.type, primary.sizeBytes);
        setInputUrl('');
        showToast('Direct Stream Started', `Downloading ${primary.filename}`, 'success');
      } else if (data.items.length > 0) {
        showToast(
          'Media Discovered',
          `Detected ${data.platformName} content with ${data.items.length} authorized asset(s).`,
          'info'
        );
      } else if (data.restrictionNotice) {
        // Show clear platform explanation
      } else {
        setErrorMsg('No accessible media streams or downloadable assets found at this URL.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Could not access target URL.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleRunPreset = (url: string) => {
    setInputUrl(url);
    handleAnalyzeOrDownload(url);
  };

  const speedMb = (systemMetrics.currentSpeedBps / (1024 * 1024)).toFixed(2);
  const totalDownloadedMb = (systemMetrics.totalBytesDownloaded / (1024 * 1024)).toFixed(1);

  return (
    <div className="space-y-6">
      {/* Hero Welcome & Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-[#142344]">
        <div>
          <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
            <span>ACP Media Downloader Pro</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0a1b38] text-[#00E5FF] border border-[#142c5c]">
              MULTI-PLATFORM EDITION
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Authorized media extraction for Facebook, YouTube, TikTok, Instagram, and direct media streams.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setCurrentPage('universal')}
            className="px-3 py-1.5 rounded-lg bg-[#0d1c3a] hover:bg-[#12264f] text-[#00E5FF] border border-[#1b3a7a] transition-colors flex items-center gap-1.5 font-medium"
          >
            <span>Universal Inspector</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-[#071024] border border-[#142344] p-3.5 rounded-xl">
          <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Transfer Throughput</span>
            <Activity className="w-3.5 h-3.5 text-[#00E5FF]" />
          </div>
          <div className="text-xl font-bold text-slate-100 font-mono tabular-nums mt-1.5 flex items-baseline gap-1">
            <span>{speedMb}</span>
            <span className="text-xs text-slate-400 font-normal">MB/s</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Real-time verified speed</div>
        </div>

        <div className="bg-[#071024] border border-[#142344] p-3.5 rounded-xl">
          <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Active Queue</span>
            <Zap className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 font-mono tabular-nums mt-1.5">
            {activeDownloads.filter((t) => t.status === 'downloading' || t.status === 'queued').length}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Concurrent streams</div>
        </div>

        <div className="bg-[#071024] border border-[#142344] p-3.5 rounded-xl">
          <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Completed Downloads</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 font-mono tabular-nums mt-1.5">
            {systemMetrics.completedCount}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Verified on local drive</div>
        </div>

        <div className="bg-[#071024] border border-[#142344] p-3.5 rounded-xl">
          <div className="text-[11px] text-slate-400 font-medium flex items-center justify-between">
            <span>Total Transferred</span>
            <HardDrive className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 font-mono tabular-nums mt-1.5 flex items-baseline gap-1">
            <span>{totalDownloadedMb}</span>
            <span className="text-xs text-slate-400 font-normal">MB</span>
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Verified byte volume</div>
        </div>
      </div>

      {/* Supported Platforms Header Strip */}
      <div className="bg-[#071024] border border-[#182a52] rounded-xl p-4 shadow-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#121f3d] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#00E5FF]/10 text-[#00E5FF] flex items-center justify-center">
              <DownloadCloud className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-100">Universal Media Downloader</h2>
              <p className="text-[11px] text-slate-400">
                Supports Facebook, YouTube, TikTok, Instagram, and Direct Video/Image links.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-950/40 text-red-400 border border-red-900/40">
              YouTube
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/40 text-cyan-400 border border-cyan-900/40">
              TikTok
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950/40 text-purple-400 border border-purple-900/40">
              Instagram
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950/40 text-blue-400 border border-blue-900/40">
              Facebook
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/40 text-emerald-400 border border-emerald-900/40">
              Direct Media
            </span>
          </div>
        </div>

        {/* Input box */}
        <div className="flex flex-col sm:flex-row gap-2 pt-1">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="Paste Facebook, YouTube, TikTok, Instagram, or direct MP4/JPG link..."
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAnalyzeOrDownload()}
              className="w-full bg-[#030712] border border-[#1b2d56] focus:border-[#00E5FF] rounded-lg px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 outline-none transition-colors font-mono"
            />
          </div>
          <button
            onClick={() => handleAnalyzeOrDownload()}
            disabled={isAnalyzing || !inputUrl.trim()}
            className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#00E5FF] to-[#0284c7] hover:opacity-95 disabled:opacity-50 text-[#040814] font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-[#00E5FF]/20 shrink-0 cursor-pointer"
          >
            {isAnalyzing ? (
              <>
                <Activity className="w-3.5 h-3.5 animate-spin" />
                <span>Inspecting Platform...</span>
              </>
            ) : (
              <>
                <DownloadCloud className="w-3.5 h-3.5" />
                <span>Download / Inspect</span>
              </>
            )}
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <div>
              <div className="font-semibold">Inspection Result</div>
              <div className="text-[11px] text-rose-200 mt-0.5">{errorMsg}</div>
            </div>
          </div>
        )}

        {/* Platform Analysis Result Card */}
        {analysisResult && (
          <div className="mt-4 p-4 rounded-xl bg-[#040814] border border-[#162a54] space-y-3 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#121f3d] pb-2.5">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-xs text-slate-100">{analysisResult.pageTitle}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0b1b38] text-[#00E5FF] border border-[#173266]">
                    {analysisResult.platformName}
                  </span>
                </div>
                {analysisResult.author && (
                  <div className="text-[11px] text-slate-400 mt-0.5">Author / Channel: {analysisResult.author}</div>
                )}
              </div>

              {analysisResult.items.length > 0 && (
                <div className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{analysisResult.items.length} Asset(s) Ready</span>
                </div>
              )}
            </div>

            {/* Platform Restriction or Guidance */}
            {analysisResult.restrictionNotice && (
              <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 font-semibold text-amber-300">
                  <Info className="w-4 h-4" />
                  <span>Platform Terms & Policy Guidance</span>
                </div>
                <p className="text-[11px] leading-relaxed text-amber-200">{analysisResult.restrictionNotice}</p>
                {analysisResult.authHelp && (
                  <div className="text-[10px] text-amber-300/90 font-mono bg-[#030712]/60 p-2 rounded border border-amber-500/20">
                    💡 Authorized Creator Guidance: {analysisResult.authHelp}
                  </div>
                )}
              </div>
            )}

            {/* Extracted Downloadable Assets */}
            {analysisResult.items.length > 0 && (
              <div className="space-y-2 pt-1">
                <div className="text-[11px] text-slate-300 font-semibold">Available Authorized Media:</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {analysisResult.items.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-lg bg-[#071024] border border-[#16274e] flex items-center justify-between text-xs gap-3"
                    >
                      <div className="truncate">
                        <div className="font-semibold text-slate-200 truncate">{item.filename}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {item.format} · {item.resolution || 'Standard Quality'}
                        </div>
                      </div>
                      <button
                        onClick={() => enqueueDownload(item.url, item.filename, item.type, item.sizeBytes)}
                        className="px-3 py-1.5 rounded-lg bg-[#00E5FF] hover:bg-[#00cbe3] text-[#040814] font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-sm shrink-0"
                      >
                        <DownloadCloud className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Five Mandatory Test Scenarios Strip */}
        <div className="mt-4 pt-3 border-t border-[#121f3d]">
          <div className="text-[11px] text-slate-400 font-medium mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span>Target Platform Test Suite (Click to verify):</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {testScenarios.map((sc, idx) => (
              <button
                key={idx}
                onClick={() => handleRunPreset(sc.url)}
                className="px-2.5 py-1.5 rounded-lg bg-[#0a1630] hover:bg-[#11244f] border border-[#182c57] hover:border-[#00E5FF]/40 text-slate-300 text-[11px] transition-all flex items-center justify-between gap-1.5 cursor-pointer text-left"
              >
                <span className="truncate">{sc.label}</span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#030712] text-[#00E5FF] border border-[#142344] shrink-0">
                  {sc.badge}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Active Transfers Live Section */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl p-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#121f3d]">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#00E5FF]" />
            <h2 className="text-sm font-semibold text-slate-100">Live Active Streams</h2>
          </div>
          <button
            onClick={() => setCurrentPage('manager')}
            className="text-[11px] text-[#00E5FF] hover:underline font-medium"
          >
            Open Task Manager ({activeDownloads.length})
          </button>
        </div>

        <div className="mt-3">
          {activeDownloads.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-1.5">
              <DownloadCloud className="w-8 h-8 text-slate-600 stroke-[1.5]" />
              <span>No active transfers in progress.</span>
              <span className="text-[11px] text-slate-600">
                Paste a URL above or choose a test sample to test real streaming.
              </span>
            </div>
          ) : (
            <div className="space-y-3">
              {activeDownloads.map((task) => {
                const speedKbs = (task.speed / 1024).toFixed(0);
                const downloadedMb = (task.downloadedBytes / (1024 * 1024)).toFixed(2);
                const totalMb = task.fileSize > 0 ? (task.fileSize / (1024 * 1024)).toFixed(2) : '?';

                return (
                  <div
                    key={task.id}
                    className="p-3 rounded-lg bg-[#040814] border border-[#142344] text-xs space-y-2"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 truncate">
                        <span className="font-semibold text-slate-200 truncate">{task.filename}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#0b1733] text-[#00E5FF] border border-[#182d5e] uppercase">
                          {task.type}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {task.status === 'downloading' && (
                          <button
                            onClick={() => pauseDownload(task.id)}
                            title="Pause"
                            className="p-1 rounded bg-[#0e1d3b] hover:bg-[#182e5e] text-slate-300 cursor-pointer"
                          >
                            <Pause className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {task.status === 'paused' && (
                          <button
                            onClick={() => resumeDownload(task.id)}
                            title="Resume"
                            className="p-1 rounded bg-[#0e1d3b] hover:bg-[#182e5e] text-[#00E5FF] cursor-pointer"
                          >
                            <Play className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => cancelDownload(task.id)}
                          title="Cancel"
                          className="p-1 rounded bg-[#0e1d3b] hover:bg-rose-900/40 text-slate-400 hover:text-rose-400 cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-1.5 rounded-full bg-[#0a1429] overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#0284c7] to-[#00E5FF] transition-all duration-300"
                        style={{ width: `${task.progress}%` }}
                      />
                    </div>

                    {/* Stats footer */}
                    <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono tabular-nums">
                      <span>
                        {downloadedMb} MB / {totalMb} MB ({task.progress}%)
                      </span>
                      <div className="flex items-center gap-3">
                        <span>Speed: {speedKbs} KB/s</span>
                        <span>ETA: {task.eta}s</span>
                        <span
                          className={`uppercase font-semibold ${
                            task.status === 'downloading'
                              ? 'text-[#00E5FF]'
                              : task.status === 'completed'
                              ? 'text-emerald-400'
                              : task.status === 'paused'
                              ? 'text-amber-400'
                              : 'text-slate-400'
                          }`}
                        >
                          {task.status}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Recent Activity Snapshot */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl p-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#121f3d]">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            <h2 className="text-sm font-semibold text-slate-100">Recent Download History</h2>
          </div>
          <button
            onClick={() => setCurrentPage('history')}
            className="text-[11px] text-[#00E5FF] hover:underline font-medium"
          >
            View Full Log ({history.length})
          </button>
        </div>

        <div className="mt-3">
          {history.length === 0 ? (
            <div className="py-6 text-center text-slate-500 text-xs">No completed downloads logged yet.</div>
          ) : (
            <div className="divide-y divide-[#0f1d3a]">
              {history.slice(0, 5).map((item) => (
                <div key={item.id} className="py-2.5 flex items-center justify-between text-xs gap-3">
                  <div className="flex items-center gap-2.5 truncate">
                    <FileText className="w-4 h-4 text-[#00E5FF] shrink-0" />
                    <div className="truncate">
                      <div className="font-medium text-slate-200 truncate">{item.filename}</div>
                      <div className="text-[10px] text-slate-500 font-mono truncate">{item.savePath}</div>
                    </div>
                  </div>
                  <div className="text-right shrink-0 font-mono text-[11px] text-slate-400">
                    <div>{(item.fileSize / (1024 * 1024)).toFixed(2)} MB</div>
                    <div className="text-[10px] text-slate-500">
                      {new Date(item.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
