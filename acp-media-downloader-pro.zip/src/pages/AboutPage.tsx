import React, { useState } from 'react';
import {
  ShieldCheck,
  Cpu,
  HardDrive,
  Download,
  Copy,
  Check,
  FileCode,
  Terminal,
  ExternalLink,
  Lock,
  Layers,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';

export const AboutPage: React.FC = () => {
  const { showToast } = useDownloadEngine();
  const [copiedScript, setCopiedScript] = useState(false);

  const nsisBuildScript = `; ==============================================================================
; ACP Media Downloader Pro - NSIS Modern Windows Installer Script
; Target: Windows 10 & Windows 11 (x64 / ARM64)
; ==============================================================================

!include "MUI2.nsh"

Name "ACP Media Downloader Pro"
OutFile "release/ACP Media Downloader Pro Setup 1.0.0.exe"
InstallDir "$LOCALAPPDATA\\Programs\\ACP Media Downloader Pro"
InstallDirRegKey HKCU "Software\\ACP\\MediaDownloaderPro" "Install_Dir"
RequestExecutionLevel user

!define MUI_ABORTWARNING
!define MUI_ICON "build/icon.ico"
!define MUI_UNICON "build/installerIcon.ico"

; Modern UI Pages
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "English"

Section "Install Application" SecCore
  SetOutPath "$INSTDIR"
  File /r "dist\\*.*"
  File /r "dist-electron\\*.*"
  
  CreateDirectory "$SMPROGRAMS\\ACP"
  CreateShortCut "$SMPROGRAMS\\ACP\\ACP Media Downloader Pro.lnk" "$INSTDIR\\ACP Media Downloader Pro.exe"
  CreateShortCut "$DESKTOP\\ACP Media Downloader Pro.lnk" "$INSTDIR\\ACP Media Downloader Pro.exe"
  
  WriteRegStr HKCU "Software\\ACP\\MediaDownloaderPro" "Install_Dir" "$INSTDIR"
  WriteUninstaller "$INSTDIR\\Uninstall.exe"
SectionEnd
`;

  const handleCopyNsis = () => {
    navigator.clipboard.writeText(nsisBuildScript);
    setCopiedScript(true);
    showToast('Copied', 'NSIS installer script copied to clipboard.', 'success');
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const handleDownloadWindowsInstaller = () => {
    window.location.href = '/api/windows-installer-package';
    showToast('Installer Downloading', 'Downloading official Windows setup installer package...', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="pb-2 border-b border-[#142344]">
        <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
          <span>About ACP Media Downloader Pro</span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#0a1b38] text-[#00E5FF] border border-[#142c5c]">
            PRODUCTION BUILD
          </span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Official Windows 10 & 11 desktop media extraction suite engineered under the ACP software brand.
        </p>
      </div>

      {/* Brand Hero Visual Showcase */}
      <div className="relative rounded-2xl overflow-hidden border border-[#182a52] bg-[#050B18] shadow-2xl">
        <img
          src="/src/assets/images/acp_software_hero_1792241923361.jpg"
          alt="ACP Media Downloader Pro Desktop Suite"
          className="w-full h-56 sm:h-64 object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#040814] via-[#040814]/40 to-transparent flex flex-col justify-end p-6">
          <div className="inline-block px-2.5 py-1 rounded bg-[#00E5FF]/20 text-[#00E5FF] text-[10px] font-bold tracking-widest uppercase border border-[#00E5FF]/30 backdrop-blur-md mb-2 w-fit">
            Enterprise Desktop Architecture
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">
            ACP Media Downloader Pro
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
            Engineered for high-throughput stream acquisition, automated asset parsing, and zero-compromise security on Windows 10 and Windows 11.
          </p>
        </div>
      </div>

      {/* Technical Specifications Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#071024] border border-[#142344] p-4 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-slate-200 text-xs font-semibold">
            <Cpu className="w-4 h-4 text-[#00E5FF]" />
            <span>Platform & Compatibility</span>
          </div>
          <div className="text-xs text-slate-300 space-y-1.5 pt-1">
            <div className="flex justify-between border-b border-[#121f3d] py-1 text-[11px]">
              <span className="text-slate-400">Target OS:</span>
              <span className="font-mono text-slate-100">Windows 10 / Windows 11</span>
            </div>
            <div className="flex justify-between border-b border-[#121f3d] py-1 text-[11px]">
              <span className="text-slate-400">Binary Architecture:</span>
              <span className="font-mono text-slate-100">x64 / ARM64</span>
            </div>
            <div className="flex justify-between py-1 text-[11px]">
              <span className="text-slate-400">Runtime Stack:</span>
              <span className="font-mono text-[#00E5FF]">Electron + React + TS</span>
            </div>
          </div>
        </div>

        <div className="bg-[#071024] border border-[#142344] p-4 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-slate-200 text-xs font-semibold">
            <HardDrive className="w-4 h-4 text-emerald-400" />
            <span>Engines & Integrations</span>
          </div>
          <div className="text-xs text-slate-300 space-y-1.5 pt-1">
            <div className="flex justify-between border-b border-[#121f3d] py-1 text-[11px]">
              <span className="text-slate-400">Media Pipeline:</span>
              <span className="font-mono text-slate-100">FFmpeg Multi-Stream Engine</span>
            </div>
            <div className="flex justify-between border-b border-[#121f3d] py-1 text-[11px]">
              <span className="text-slate-400">Database Engine:</span>
              <span className="font-mono text-slate-100">SQLite WAL Storage</span>
            </div>
            <div className="flex justify-between py-1 text-[11px]">
              <span className="text-slate-400">Streaming Protocol:</span>
              <span className="font-mono text-emerald-400">HTTP/2 Range Stream</span>
            </div>
          </div>
        </div>

        <div className="bg-[#071024] border border-[#142344] p-4 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-slate-200 text-xs font-semibold">
            <Lock className="w-4 h-4 text-amber-400" />
            <span>Security Hardening</span>
          </div>
          <div className="text-xs text-slate-300 space-y-1.5 pt-1">
            <div className="flex justify-between border-b border-[#121f3d] py-1 text-[11px]">
              <span className="text-slate-400">Perimeter Defense:</span>
              <span className="font-mono text-emerald-400">SSRF IP Whitelisting</span>
            </div>
            <div className="flex justify-between border-b border-[#121f3d] py-1 text-[11px]">
              <span className="text-slate-400">File Sandbox:</span>
              <span className="font-mono text-slate-100">Strict Path Traversal Guard</span>
            </div>
            <div className="flex justify-between py-1 text-[11px]">
              <span className="text-slate-400">Credential Policy:</span>
              <span className="font-mono text-slate-100">Zero Password Interception</span>
            </div>
          </div>
        </div>
      </div>

      {/* Windows .exe Installer Package Deliverable */}
      <div className="bg-[#071024] border border-[#182a52] rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Download className="w-4 h-4 text-[#00E5FF]" />
              <span>Official Windows .exe Installer Package</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Generate and download the production Windows installer package for ACP Media Downloader Pro.
            </p>
          </div>

          <button
            onClick={handleDownloadWindowsInstaller}
            className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#00E5FF] to-[#0284c7] hover:opacity-95 text-[#040814] font-bold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#00E5FF]/20 shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Windows Installer (.bat / .exe)</span>
          </button>
        </div>

        {/* NSIS Script Inspector */}
        <div className="bg-[#030712] border border-[#132242] rounded-lg p-3 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <FileCode className="w-3.5 h-3.5 text-[#00E5FF]" />
              <span className="font-mono font-medium text-slate-300">installer.nsi (Windows NSIS Setup Spec)</span>
            </div>
            <button
              onClick={handleCopyNsis}
              className="text-[11px] text-[#00E5FF] hover:underline flex items-center gap-1 cursor-pointer"
            >
              {copiedScript ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedScript ? 'Copied to Clipboard' : 'Copy Build Script'}</span>
            </button>
          </div>
          <pre className="text-[11px] font-mono text-slate-400 overflow-x-auto max-h-40 p-2 bg-[#02050d] rounded border border-[#0d172e] leading-relaxed">
            {nsisBuildScript}
          </pre>
        </div>
      </div>

      {/* Compliance & DRM Statement */}
      <div className="p-4 rounded-xl bg-[#071024] border border-[#142344] text-xs text-slate-400 space-y-2">
        <div className="font-semibold text-slate-200 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Legal & Authorized Media Use Statement</span>
        </div>
        <p className="leading-relaxed text-[11px] text-slate-400">
          ACP Media Downloader Pro is developed strictly for downloading publicly accessible media, open educational resources, creative assets, and content where authorized by the hosting provider or copyright owner. The application contains no circumvention mechanisms for Digital Rights Management (DRM), paywalls, or authenticated personal accounts.
        </p>
        <div className="pt-2 text-[10px] text-slate-500 font-mono">
          ACP Software Corporation · ACP Media Downloader Pro v1.0.0 · Build ID #WIN11-PRO-2026-X64
        </div>
      </div>
    </div>
  );
};
