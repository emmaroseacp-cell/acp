import React, { useState } from 'react';
import {
  Layers,
  DownloadCloud,
  CheckSquare,
  Square,
  Archive,
  Trash2,
  Plus,
  Play,
  AlertCircle,
  FileText,
  Activity,
} from 'lucide-react';
import { useDownloadEngine } from '../context/DownloadEngineContext';
import { MediaType } from '../types';

interface BatchItem {
  id: string;
  url: string;
  filename: string;
  type: MediaType;
  selected: boolean;
}

export const BatchDownloader: React.FC = () => {
  const { enqueueBatchDownloads, downloadAsZip, showToast } = useDownloadEngine();

  const [rawText, setRawText] = useState('');
  const [parsedItems, setParsedItems] = useState<BatchItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleParseUrls = () => {
    const lines = rawText
      .split('\n')
      .map((l) => l.trim())
      .filter((l) => l.length > 0)
      .map((l) => (l.startsWith('http://') || l.startsWith('https://') ? l : 'https://' + l));

    if (lines.length === 0) {
      showToast('No Valid URLs', 'Please enter at least one valid web address.', 'warning');
      return;
    }

    const newItems: BatchItem[] = lines.map((urlStr, index) => {
      try {
        const u = new URL(urlStr);
        const base = u.pathname.split('/').pop() || `batch_item_${index + 1}`;
        const ext = base.split('.').pop()?.toLowerCase() || '';

        let detectedType: MediaType = 'document';
        if (['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'].includes(ext)) detectedType = 'image';
        else if (['mp4', 'webm', 'mov', 'mkv', 'avi'].includes(ext)) detectedType = 'video';
        else if (['mp3', 'wav', 'flac', 'aac', 'ogg'].includes(ext)) detectedType = 'audio';

        const safeFilename = base.includes('.') ? base : `${base}.${detectedType === 'image' ? 'jpg' : 'dat'}`;

        return {
          id: `batch_${Date.now()}_${index}`,
          url: urlStr,
          filename: safeFilename,
          type: detectedType,
          selected: true,
        };
      } catch {
        return {
          id: `batch_${Date.now()}_${index}`,
          url: urlStr,
          filename: `download_${index + 1}.dat`,
          type: 'document',
          selected: true,
        };
      }
    });

    setParsedItems(newItems);
    showToast('URLs Parsed', `Recognized ${newItems.length} media links.`, 'success');
  };

  const handleToggleSelect = (id: string) => {
    setParsedItems((prev) => prev.map((item) => (item.id === id ? { ...item, selected: !item.selected } : item)));
  };

  const handleToggleAll = () => {
    const allSelected = parsedItems.every((i) => i.selected);
    setParsedItems((prev) => prev.map((item) => ({ ...item, selected: !allSelected })));
  };

  const handleStartBatch = () => {
    const activeOnes = parsedItems.filter((i) => i.selected);
    if (activeOnes.length === 0) {
      showToast('Notice', 'No items selected for download.', 'warning');
      return;
    }

    enqueueBatchDownloads(
      activeOnes.map((item) => ({
        url: item.url,
        filename: item.filename,
        type: item.type,
      }))
    );
    showToast('Batch Started', `Queued ${activeOnes.length} downloads. Check Download Manager.`, 'success');
  };

  const handleZipBatch = () => {
    const activeOnes = parsedItems.filter((i) => i.selected);
    if (activeOnes.length === 0) return;
    downloadAsZip(
      activeOnes.map((i) => ({ url: i.url, filename: i.filename })),
      `ACP_Batch_Archive_${Date.now()}.zip`
    );
  };

  const loadPresetUrls = () => {
    const samples = [
      'https://upload.wikimedia.org/wikipedia/commons/9/97/The_Earth_seen_from_Apollo_17.jpg',
      'https://upload.wikimedia.org/wikipedia/commons/4/4f/SVG_Logo.svg',
      'https://www.w3schools.com/html/horse.mp3',
      'https://images-assets.nasa.gov/video/NHQ_2019_0716_Apollo%2011%2050th%20Anniversary%20Broadcast/NHQ_2019_0716_Apollo%2011%2050th%20Anniversary%20Broadcast~orig.mp4',
    ];
    setRawText(samples.join('\n'));
  };

  const selectedCount = parsedItems.filter((i) => i.selected).length;

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="pb-2 border-b border-[#142344]">
        <h1 className="text-xl font-bold text-slate-100 tracking-tight flex items-center gap-2">
          <Layers className="w-5 h-5 text-[#00E5FF]" />
          <span>Batch Media Downloader</span>
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Queue multiple media links simultaneously with concurrency throttling and multi-threaded stream distribution.
        </p>
      </div>

      {/* Input Textarea Area */}
      <div className="bg-[#071024] border border-[#142344] rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-200">
            Paste Multiple URLs (One URL Per Line):
          </label>
          <button
            onClick={loadPresetUrls}
            className="text-[11px] text-[#00E5FF] hover:underline cursor-pointer"
          >
            Insert Verification URLs
          </button>
        </div>

        <textarea
          rows={5}
          placeholder="https://example.com/photo1.jpg&#10;https://example.com/video.mp4&#10;https://example.com/audio.mp3"
          value={rawText}
          onChange={(e) => setRawText(e.target.value)}
          className="w-full bg-[#030712] border border-[#1b2d56] focus:border-[#00E5FF] rounded-lg p-3 text-xs text-slate-100 placeholder-slate-500 font-mono outline-none"
        />

        <div className="flex items-center justify-between pt-1">
          <span className="text-[11px] text-slate-500">
            Supports mixed media (Images, Videos, Audio, Documents)
          </span>
          <button
            onClick={handleParseUrls}
            disabled={!rawText.trim()}
            className="px-5 py-2 rounded-lg bg-gradient-to-r from-[#00E5FF] to-[#0284c7] hover:opacity-95 disabled:opacity-50 text-[#040814] font-bold text-xs flex items-center gap-2 cursor-pointer shadow-md shadow-[#00E5FF]/20"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Parse & Prepare Batch</span>
          </button>
        </div>
      </div>

      {/* Parsed List Table */}
      {parsedItems.length > 0 && (
        <div className="bg-[#071024] border border-[#142344] rounded-xl overflow-hidden shadow-lg space-y-3">
          {/* Header Controls */}
          <div className="p-3.5 bg-[#050B18] border-b border-[#142344] flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <button
                onClick={handleToggleAll}
                className="flex items-center gap-1.5 text-slate-300 hover:text-white"
              >
                {selectedCount === parsedItems.length ? (
                  <CheckSquare className="w-4 h-4 text-[#00E5FF]" />
                ) : (
                  <Square className="w-4 h-4 text-slate-400" />
                )}
                <span>Select All ({parsedItems.length})</span>
              </button>
              <span className="text-slate-600">·</span>
              <span className="text-[#00E5FF] font-medium">{selectedCount} ready to download</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleZipBatch}
                disabled={selectedCount === 0}
                className="px-3 py-1.5 rounded-lg bg-[#0e1d3b] hover:bg-[#162e5c] text-[#00E5FF] border border-[#00E5FF]/30 disabled:opacity-50 flex items-center gap-1.5 font-medium cursor-pointer"
              >
                <Archive className="w-3.5 h-3.5" />
                <span>Bundle to ZIP</span>
              </button>
              <button
                onClick={handleStartBatch}
                disabled={selectedCount === 0}
                className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-[#00E5FF] to-[#0284c7] hover:opacity-95 disabled:opacity-50 text-[#040814] font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <DownloadCloud className="w-3.5 h-3.5" />
                <span>Start Batch ({selectedCount})</span>
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#040814] text-slate-400 border-b border-[#121f3d] font-semibold text-[11px]">
                <tr>
                  <th className="py-2.5 px-3 w-10"></th>
                  <th className="py-2.5 px-3">Filename</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">URL Endpoint</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0f1d3b]">
                {parsedItems.map((item) => (
                  <tr key={item.id} className="hover:bg-[#09152e] transition-colors">
                    <td className="py-2.5 px-3">
                      <button
                        onClick={() => handleToggleSelect(item.id)}
                        className="text-slate-400 hover:text-white"
                      >
                        {item.selected ? (
                          <CheckSquare className="w-4 h-4 text-[#00E5FF]" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-500" />
                        )}
                      </button>
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-200">
                      {item.filename}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#030712] text-[#00E5FF] border border-[#16274e] uppercase">
                        {item.type}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-400 text-[11px] truncate max-w-xs">
                      {item.url}
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => setParsedItems((prev) => prev.filter((i) => i.id !== item.id))}
                        className="p-1 rounded text-slate-400 hover:text-rose-400"
                        title="Remove from batch"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
